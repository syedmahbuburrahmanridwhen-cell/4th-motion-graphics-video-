import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { CL, Pop, Words, ramp, useSp } from "../components/Motion";
import { Icon } from "../components/Icons";
import { Avatar, Chip, Glass, Ripple, Skel, Spark } from "../components/Ui";
import { useC } from "../components/Tone";
import { SfxEvent } from "../components/Sfx";
import { Timer, makeTimer } from "../timing";
import { theme } from "../theme";
import { PHONE_IN } from "../phoneTiming";

export const T9A = makeTimer(24, 28);
export const sfx9a = (T: Timer): SfxEvent[] => [
  { at: T.from + 6, name: "pop", vol: 0.9 },
  { at: PHONE_IN + 6, name: "pluck", vol: 0.9 },
  { at: T.from + T.t(25) + 8, name: "pop" },
  { at: T.from + T.t(25) + 46, name: "click", vol: 0.9 },
  { at: T.from + T.t(26) + 6, name: "chime", vol: 0.9 },
];

const SunDial: React.FC<{ a: number; b: number; out: number }> = ({ a, b, out }) => {
  const frame = useCurrentFrame();
  const c = useC();
  const u = ramp(frame, a, b, theme.ease.inOut);
  const x = 430 - 340 * Math.cos(Math.PI * u);
  const y = 310 - 270 * Math.sin(Math.PI * u);
  const arcLen = 1000;
  return (
    <Pop delay={a - 14} out={out} from="bottom" dist={60} preset="smooth" s={0.92}>
      <Glass w={860} h={400} r={42} strong>
        <div style={{ position: "absolute", left: 36, top: 30 }}>
          <Chip text="দিনের বেলা" icon="sun" size={28} />
        </div>
        <svg width={860} height={400} viewBox="0 0 860 400" style={{ position: "absolute", inset: 0 }}>
          <path d="M 90 310 A 340 270 0 0 1 770 310" fill="none" stroke={c.lineStrong} strokeWidth={3} strokeDasharray="4 14" strokeLinecap="round" />
          <path d="M 90 310 A 340 270 0 0 1 770 310" fill="none" stroke={c.hero} strokeWidth={4} strokeLinecap="round" strokeDasharray={`${arcLen * u} ${arcLen * 2}`} opacity={0.9} />
          <line x1={50} y1={310} x2={810} y2={310} stroke={c.lineStrong} strokeWidth={2} />
          <g transform={`translate(${x} ${y})`} style={{ filter: `drop-shadow(0 0 26px ${theme.colors.glow})` }}>
            {Array.from({ length: 10 }).map((_, i) => (
              <line key={i} x1={0} y1={-40} x2={0} y2={-54} stroke={c.hero} strokeWidth={5} strokeLinecap="round" transform={`rotate(${i * 36 + frame * 0.8})`} />
            ))}
            <circle r={30} fill={c.hero} />
          </g>
        </svg>
      </Glass>
    </Pop>
  );
};

const InboxCard: React.FC<{ at: number; out: number }> = ({ at, out }) => {
  const frame = useCurrentFrame();
  const c = useC();
  const clickAt = at + 40;
  const sent = ramp(frame, clickAt + 4, clickAt + 26, theme.ease.inOut);
  const tick = ramp(frame, clickAt + 22, clickAt + 34);
  return (
    <Pop delay={at} out={out} from="bottom" dist={70} preset="smooth" s={0.92}>
      <Glass w={860} h={400} r={42} strong pad={34}>
        <div style={{ display: "flex", alignItems: "center", gap: 20, marginBottom: 26 }}>
          <div style={{ width: 78, height: 78, borderRadius: 26, background: c.hero, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Icon name="mail" size={42} color={c.onHero} stroke={1.7} />
          </div>
          <div style={{ fontFamily: theme.fonts.main, fontWeight: theme.weight.heavy, fontSize: 48, color: c.fg, lineHeight: 1.3, flex: 1 }}>Inbox</div>
          <Avatar size={64} icon="user" />
        </div>
        <div style={{ height: 150, borderRadius: 28, border: `1px solid ${c.lineStrong}`, padding: "28px 32px", position: "relative", overflow: "hidden" }}>
          <div style={{ transform: `translate(${sent * 520}px, ${-sent * 60}px)`, opacity: 1 - sent }}>
            <Skel widths={[540, 420, 260]} h={15} gap={14} delay={at + 12} />
          </div>
        </div>
        <div style={{ display: "flex", justifyContent: "flex-end", alignItems: "center", gap: 20, marginTop: 24, position: "relative" }}>
          <div style={{ opacity: tick, transform: `scale(${0.4 + 0.6 * tick})`, width: 56, height: 56, borderRadius: 56, background: c.hero, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Icon name="check" size={32} color={c.onHero} stroke={3} />
          </div>
          <div style={{ position: "relative" }}>
            <Chip text="message" icon="send" size={32} solid style={{ transform: `scale(${frame > clickAt && frame < clickAt + 6 ? 0.93 : 1})` }} />
            <div style={{ position: "absolute", left: "50%", top: "50%" }}>
              <Ripple at={clickAt} size={140} />
            </div>
          </div>
        </div>
      </Glass>
    </Pop>
  );
};

export const S09aInbox: React.FC = () => {
  const T = T9A;
  const t25 = T.t(25);
  const t26 = T.t(26);
  const t27 = T.t(27);
  const c = useC();
  const dialA = T.t(24, 0.42);
  return (
    <SceneShell tone="dark" bg="spot">
      <AbsoluteFill>
        {/* No worry */}
        <div style={{ position: "absolute", left: 130, top: 120 }}>
          <Words text="No worry," size={150} delay={2} per={6} dim={[0]} grad={[1]} out={t26 - 2} />
        </div>
        <div style={{ position: "absolute", left: 130, top: 340 }}>
          <SunDial a={dialA} b={t25 + 6} out={t25 + 2} />
        </div>
        <div style={{ position: "absolute", left: 130, top: 340 }}>
          <InboxCard at={t25} out={t26 - 2} />
        </div>
        <div style={{ position: "absolute", left: 130, top: 800 }}>
          <Words text="inbox এ একটা message দিন" size={64} delay={t25 + 6} per={4} dim={[1, 2]} mark={[0]} hero={[3, 4]} out={t26 - 2} maxWidth={940} />
        </div>

        {/* best টা দিয়ে help */}
        <div style={{ position: "absolute", left: 130, top: 150, width: 420, height: 420 }}>
          <Pop delay={t26} from="none" preset="bouncy" s={0.3}>
            <div style={{ position: "relative", width: 420, height: 420 }}>
              <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <Spark size={420} delay={t26 + 6} />
              </div>
              <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", filter: `drop-shadow(0 0 40px ${theme.colors.glow})` }}>
                <Icon name="star" size={190} color={c.hero} fill={c.hero} stroke={1} style={{ transform: `rotate(${Math.sin(t26 / 10) * 4}deg)` }} />
              </div>
            </div>
          </Pop>
        </div>
        <div style={{ position: "absolute", left: 130, top: 600 }}>
          <Words text="আমার best টা দিয়ে" size={96} delay={t26 + 4} per={5} dim={[0]} grad={[1]} hero={[2, 3]} maxWidth={940} />
        </div>
        <div style={{ position: "absolute", left: 130, top: 760 }}>
          <Words text="help করার চেষ্টা করব" size={96} delay={t27} per={5} mark={[0]} hero={[1, 2, 3]} maxWidth={940} />
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
