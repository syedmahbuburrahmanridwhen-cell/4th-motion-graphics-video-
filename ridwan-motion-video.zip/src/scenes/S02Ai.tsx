import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { CL, Pop, Words, ramp, useBreathe, useFloat } from "../components/Motion";
import { Icon } from "../components/Icons";
import { Avatar, Chip, Glass, Skel } from "../components/Ui";
import { useC } from "../components/Tone";
import { SfxEvent } from "../components/Sfx";
import { Timer, makeTimer } from "../timing";
import { theme } from "../theme";

export const T2 = makeTimer(4, 6);
export const sfx2 = (T: Timer): SfxEvent[] => [
  { at: T.from + 14, name: "pop" },
  { at: T.from + T.t(5) + 8, name: "pop", rate: 1.08, vol: 0.9 },
  { at: T.from + T.t(5) + 46, name: "click", vol: 0.8 },
];

const Bubble: React.FC<{ side: "left" | "right"; delay: number; widths: number[]; out?: number }> = ({ side, delay, widths, out }) => {
  const c = useC();
  const mine = side === "right";
  return (
    <Pop delay={delay} out={out} from={side} dist={60} preset="snappy" s={0.86} origin={mine ? "100% 50%" : "0% 50%"}>
      <div style={{ display: "flex", justifyContent: mine ? "flex-end" : "flex-start" }}>
        <div
          style={{
            padding: "26px 30px",
            borderRadius: 30,
            borderBottomRightRadius: mine ? 8 : 30,
            borderBottomLeftRadius: mine ? 30 : 8,
            background: mine ? c.hero : `${theme.alpha.white(0.09)}`,
            border: `1px solid ${mine ? "transparent" : c.line}`,
          }}
        >
          <Skel widths={widths} h={15} delay={delay + 6} hero={mine} align={mine ? "right" : "left"} />
        </div>
      </div>
    </Pop>
  );
};

const Typing: React.FC<{ delay: number; hideAt: number }> = ({ delay, hideAt }) => {
  const frame = useCurrentFrame();
  const c = useC();
  if (frame > hideAt + 10) return null;
  return (
    <Pop delay={delay} out={hideAt} from="right" dist={50} preset="snappy" s={0.8} origin="100% 50%">
      <div style={{ display: "flex", justifyContent: "flex-end" }}>
        <div style={{ padding: "26px 32px", borderRadius: 30, borderBottomRightRadius: 8, background: c.hero, display: "flex", gap: 12 }}>
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              style={{
                width: 14,
                height: 14,
                borderRadius: 14,
                background: c.onHero,
                transform: `translateY(${-Math.abs(Math.sin((frame - i * 4) / 6)) * 10}px)`,
                opacity: 0.85,
              }}
            />
          ))}
        </div>
      </div>
    </Pop>
  );
};

export const S02Ai: React.FC = () => {
  const T = T2;
  const t5 = T.t(5);
  const c = useC();
  const fl = useFloat(6, 140);
  const br = useBreathe(110, 0.008);
  const frame = useCurrentFrame();
  const link = ramp(frame, 18, 60);
  return (
    <SceneShell tone="dark" bg="grid">
      <AbsoluteFill>
        {/* বাম: শিরোনাম */}
        <div style={{ position: "absolute", left: 130, top: 170 }}>
          <Words text="আমার হয়ে" size={86} delay={2} per={4} dim={[0, 1]} />
        </div>
        <div style={{ position: "absolute", left: 130, top: 290 }}>
          <Words text="আমার AI management system" size={104} delay={10} per={5} maxWidth={820} mark={[1]} hero={[2, 3]} />
        </div>
        <div style={{ position: "absolute", left: 130, top: 800 }}>
          <Pop delay={t5} from="bottom" dist={30}>
            <div style={{ display: "flex", alignItems: "center", gap: 22 }}>
              <Icon name="chat" size={54} color={c.hero} />
              <Words text="তার সাথে কথা বলছিল" size={62} delay={t5 + 2} per={4} dim={[0, 1]} hero={[2, 3]} />
            </div>
          </Pop>
        </div>

        {/* ডান: চ্যাট উইন্ডো */}
        <div style={{ position: "absolute", left: 1010, top: 150 + fl, width: 780, transform: `scale(${br})`, transformOrigin: "50% 50%" }}>
          <Pop delay={4} from="right" dist={200} preset="smooth" s={0.92}>
            <Glass w={780} h={780} r={44} strong>
              {/* হেডার */}
              <div style={{ height: 124, padding: "0 36px", display: "flex", alignItems: "center", gap: 22, borderBottom: `1px solid ${c.line}` }}>
                <Avatar size={72} icon="bot" solid />
                <div style={{ display: "flex", flexDirection: "column", gap: 10, flex: 1 }}>
                  <div style={{ fontFamily: theme.fonts.main, fontWeight: theme.weight.strong, fontSize: 30, color: c.fg, lineHeight: 1.2 }}>
                    AI Management System
                  </div>
                  <Skel widths={[190]} h={11} delay={14} />
                </div>
                {/* সংযোগ: AI ↔ client */}
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  {[0, 1, 2].map((i) => (
                    <div
                      key={i}
                      style={{
                        width: 9,
                        height: 9,
                        borderRadius: 9,
                        background: c.hero,
                        opacity: 0.3 + 0.7 * Math.max(0, Math.sin((frame - i * 5) / 7)) * link,
                      }}
                    />
                  ))}
                  <Avatar size={60} icon="user" />
                </div>
              </div>
              {/* মেসেজ */}
              <div style={{ padding: "34px 36px", display: "flex", flexDirection: "column", gap: 24 }}>
                <Bubble side="left" delay={20} widths={[330, 240]} />
                <Bubble side="right" delay={34} widths={[360, 290, 170]} />
                <Bubble side="left" delay={t5 + 4} widths={[250]} />
                <Typing delay={t5 + 18} hideAt={t5 + 46} />
                <Pop delay={t5 + 46} from="right" dist={50} preset="snappy" s={0.86} origin="100% 50%" style={{ marginTop: -78 }}>
                  <div style={{ display: "flex", justifyContent: "flex-end" }}>
                    <div style={{ padding: "26px 30px", borderRadius: 30, borderBottomRightRadius: 8, background: c.hero }}>
                      <Skel widths={[330, 250]} h={15} delay={t5 + 52} hero align="right" />
                    </div>
                  </div>
                </Pop>
              </div>
              {/* ইনপুট বার */}
              <div style={{ position: "absolute", left: 36, right: 36, bottom: 32, height: 76, borderRadius: 40, border: `1px solid ${c.lineStrong}`, display: "flex", alignItems: "center", padding: "0 14px 0 34px", gap: 20 }}>
                <div style={{ flex: 1 }}>
                  <Skel widths={[260]} h={13} delay={24} />
                </div>
                <div style={{ width: 52, height: 52, borderRadius: 52, background: c.hero, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <Icon name="send" size={26} color={c.onHero} />
                </div>
              </div>
            </Glass>
          </Pop>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
