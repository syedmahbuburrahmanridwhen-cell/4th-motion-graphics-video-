import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { CL, Pop, Words, ramp, useSp } from "../components/Motion";
import { Icon } from "../components/Icons";
import { Chip, Cursor, Ripple, Skel } from "../components/Ui";
import { useC } from "../components/Tone";
import { SfxEvent } from "../components/Sfx";
import { Timer, makeTimer } from "../timing";
import { theme } from "../theme";

export const T7 = makeTimer(18, 21);
export const sfx7 = (T: Timer): SfxEvent[] => [
  { at: T.from + 10, name: "pop" },
  { at: T.from + T.t(19) + 30, name: "click", vol: 0.9 },
  { at: T.from + T.t(19) + 34, name: "chime", vol: 0.8 },
  { at: T.from + T.t(20, 0.3), name: "pop", rate: 1.1, vol: 0.85 },
];

const N = 7;
const STEP = 360 / N;
const RAD = 940;

const Card: React.FC<{ i: number; angle: number; live: number }> = ({ i, angle, live }) => {
  const c = useC();
  const th = (((angle + i * STEP) % 360) + 360) % 360;
  const cos = Math.cos((th * Math.PI) / 180);
  const op = 0.3 + 0.7 * Math.max(0, (cos + 0.1) / 1.1);
  const front = i === 0;
  return (
    <div
      style={{
        position: "absolute",
        left: -290,
        top: -210,
        width: 580,
        height: 420,
        transform: `rotateY(${i * STEP}deg) translateZ(${RAD}px)`,
        opacity: op,
        backfaceVisibility: "hidden",
      }}
    >
      <div
        style={{
          width: "100%",
          height: "100%",
          borderRadius: 34,
          boxSizing: "border-box",
          padding: 26,
          background: `linear-gradient(160deg, ${theme.alpha.white(0.14)}, ${theme.alpha.white(0.04)})`,
          border: `1px solid ${front && live > 0.5 ? c.hero : c.lineStrong}`,
          boxShadow: `0 40px 80px -30px ${c.shadow}, inset 0 1px 0 ${theme.alpha.white(0.16)}`,
          position: "relative",
        }}
      >
        <div style={{ height: 180, borderRadius: 22, background: `${theme.alpha.white(0.09)}`, marginBottom: 22, position: "relative", overflow: "hidden" }}>
          <div style={{ position: "absolute", left: 26, top: 26, width: 170 - (i % 3) * 20, height: 14, borderRadius: 14, background: `${theme.alpha.white(0.28)}` }} />
          <div style={{ position: "absolute", left: 26, top: 54, width: 110, height: 14, borderRadius: 14, background: `${theme.alpha.white(0.16)}` }} />
          <div style={{ position: "absolute", right: 24, bottom: 20, width: 64, height: 64, borderRadius: 18, background: `${theme.alpha.white(0.14)}` }} />
        </div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <Skel widths={[200, 130]} h={14} gap={10} delay={20} />
          <div
            style={{
              padding: "14px 26px",
              borderRadius: 40,
              background: front && live > 0.5 ? c.hero : `${theme.alpha.white(0.1)}`,
              color: front && live > 0.5 ? c.onHero : c.fg,
              fontFamily: theme.fonts.main,
              fontWeight: theme.weight.strong,
              fontSize: 26,
              lineHeight: 1.2,
            }}
          >
            Demo
          </div>
        </div>
      </div>
    </div>
  );
};

export const S07Carousel: React.FC = () => {
  const T = T7;
  const t19 = T.t(19);
  const t20 = T.t(20);
  const q2 = T.t(20, 0.3);
  const frame = useCurrentFrame();
  const c = useC();
  const intro = useSp(2, "slow");
  const angle = interpolate(frame, [4, t19 + 10], [-252, 0], { ...CL, easing: theme.ease.out });
  const live = ramp(frame, t19 + 26, t19 + 34);
  // কার্সর: নিচ-ডান থেকে সামনের কার্ডের Demo বাটনে
  const cp = ramp(frame, t19 + 4, t19 + 30, theme.ease.inOut);
  const cx = interpolate(cp, [0, 1], [1600, 1190]);
  const cy = interpolate(cp, [0, 1], [930, 700]);
  const pulse = 1 + (frame > t19 + 30 ? Math.sin((frame - t19 - 30) / 6) * 0.02 : 0);
  return (
    <SceneShell tone="dark" bg="globe" globe={{ cx: 960, cy: 560, R: 430, op: 0.55 }}>
      <AbsoluteFill>
        <div style={{ position: "absolute", left: 0, right: 0, top: 60, display: "flex", justifyContent: "center" }}>
          <Words text="এখন যেসব project বানাবো" size={84} delay={2} per={4} align="center" dim={[0, 1]} hero={[2]} grad={[3]} />
        </div>

        {/* 3D ক্যারোসেল */}
        <div style={{ position: "absolute", inset: 0, perspective: 2300, perspectiveOrigin: "50% 48%", opacity: Math.min(1, intro * 1.5) }}>
          <div
            style={{
              position: "absolute",
              left: 960,
              top: 530,
              width: 0,
              height: 0,
              transformStyle: "preserve-3d",
              transform: `translateZ(${-RAD}px) scale(${pulse}) rotateY(${angle}deg)`,
            }}
          >
            {Array.from({ length: N }).map((_, i) => (
              <Card key={i} i={i} angle={angle} live={live} />
            ))}
          </div>
        </div>

        {/* LIVE ব্যাজ */}
        <div style={{ position: "absolute", left: 960 + 150, top: 250 }}>
          <Pop delay={t19 + 24} from="bottom" dist={20} preset="bouncy" s={0.5}>
            <Chip text="LIVE" size={30} solid style={{ boxShadow: `0 0 50px ${theme.colors.glow}` }} />
          </Pop>
        </div>

        {/* কার্সর */}
        {frame > t19 + 3 && (
          <div style={{ position: "absolute", left: cx, top: cy, opacity: ramp(frame, t19 + 3, t19 + 10) * (1 - ramp(frame, t20 + 6, t20 + 16)) }}>
            <Cursor size={54} />
            <div style={{ position: "absolute", left: 6, top: 6 }}>
              <Ripple at={t19 + 30} size={120} />
            </div>
          </div>
        )}

        {/* নিচের বার্তা */}
        <div style={{ position: "absolute", left: 0, right: 0, top: 880, display: "flex", justifyContent: "center" }}>
          <Words text="live demo সরাসরি সাইটে" size={74} delay={t19 + 2} per={4} align="center" mark={[0, 1]} dim={[2, 3]} out={t20 - 10} />
        </div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 880, display: "flex", justifyContent: "center" }}>
          <Pop delay={t20 + 2} from="bottom" dist={30} preset="bouncy" s={0.8}>
            <div style={{ display: "flex", alignItems: "center", gap: 22 }}>
              <div style={{ width: 70, height: 70, borderRadius: 70, background: c.hero, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <Icon name="check" size={40} color={c.onHero} stroke={3} />
              </div>
              <Words text="পেয়ে যাবেন" size={80} delay={t20 + 4} per={4} hero={[0, 1]} />
            </div>
          </Pop>
        </div>

        {/* দ্বিতীয় প্রশ্নের আভাস */}
        <div style={{ position: "absolute", right: 120, top: 70 }}>
          <Pop delay={q2} from="right" dist={80} preset="bouncy" s={0.7}>
            <Chip text="Q2" size={40} solid />
          </Pop>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
