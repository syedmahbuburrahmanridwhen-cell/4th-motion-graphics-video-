import React from "react";
import { AbsoluteFill } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { Pop, Words, useBreathe } from "../components/Motion";
import { Icon } from "../components/Icons";
import { Chip, Glass } from "../components/Ui";
import { useC } from "../components/Tone";
import { SfxEvent } from "../components/Sfx";
import { Timer, makeTimer } from "../timing";
import { theme } from "../theme";

export const T9B = makeTimer(28, 30);
export const sfx9b = (T: Timer): SfxEvent[] => [
  { at: T.from + 6, name: "pop" },
  { at: T.from + 16, name: "pop", rate: 1.08, vol: 0.85 },
  { at: T.from + T.t(29) + 6, name: "chime", vol: 0.9 },
];

const Role: React.FC<{ icon: string; label: string; delay: number }> = ({ icon, label, delay }) => {
  const c = useC();
  const br = useBreathe(110, 0.01, delay);
  return (
    <Pop delay={delay} from="bottom" dist={70} preset="bouncy" s={0.8}>
      <div style={{ transform: `scale(${br})` }}>
        <Glass w={420} h={300} r={42} pad={34} strong>
          <div style={{ display: "flex", flexDirection: "column", height: "100%", justifyContent: "space-between" }}>
            <div style={{ width: 100, height: 100, borderRadius: 32, background: c.hero, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Icon name={icon} size={54} color={c.onHero} stroke={1.7} />
            </div>
            <div style={{ fontFamily: theme.fonts.main, fontWeight: theme.weight.heavy, fontSize: 46, color: c.fg, lineHeight: 1.3 }}>{label}</div>
          </div>
        </Glass>
      </div>
    </Pop>
  );
};

export const S09bPremium: React.FC = () => {
  const T = T9B;
  const t29 = T.t(29);
  return (
    <SceneShell tone="dark" bg="mesh">
      <AbsoluteFill>
        <div style={{ position: "absolute", left: 130, top: 120, display: "flex", alignItems: "center", gap: 0 }}>
          <Role icon="briefcase" label="Business" delay={2} />
          <div style={{ width: 60, display: "flex", justifyContent: "center", zIndex: 2, marginLeft: -2 }}>
            <Pop delay={12} from="none" preset="bouncy" s={0.3}>
              <Chip text="বা" size={32} solid />
            </Pop>
          </div>
          <Role icon="user" label="Personal Brand" delay={8} />
        </div>

        <div style={{ position: "absolute", left: 130, top: 470 }}>
          <Words text="premium website" size={132} delay={t29} per={7} maxWidth={940} grad={[0]} hero={[1]} />
        </div>
        <div style={{ position: "absolute", left: 130, top: 836 }}>
          <Pop delay={t29 + 16} from="bottom" dist={34} preset="bouncy" s={0.8}>
            <div style={{ display: "flex", alignItems: "center", gap: 22 }}>
              <Icon name="sparkles" size={64} color={useC().hero} stroke={1.5} />
              <Words text="বানাতে চান" size={72} delay={t29 + 18} per={5} dim={[0, 1]} />
            </div>
          </Pop>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
