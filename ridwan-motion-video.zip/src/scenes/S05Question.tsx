import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { Pop, Words, ramp, useBreathe, useSp } from "../components/Motion";
import { Icon } from "../components/Icons";
import { Chip, Glass, Skel } from "../components/Ui";
import { useC } from "../components/Tone";
import { SfxEvent } from "../components/Sfx";
import { Timer, makeTimer } from "../timing";
import { theme } from "../theme";

export const T5 = makeTimer(11, 14);
export const sfx5 = (T: Timer): SfxEvent[] => [
  { at: T.from + 6, name: "pop", vol: 0.9 },
  { at: T.from + T.t(12) + 6, name: "pop", rate: 1.05 },
  { at: T.from + T.t(13) + 10, name: "click", vol: 0.8 },
];

const ProjectCard: React.FC<{ delay: number; empty?: boolean; emptyAt?: number }> = ({ delay, empty, emptyAt = 0 }) => {
  const frame = useCurrentFrame();
  const c = useC();
  const e = empty ? ramp(frame, emptyAt, emptyAt + 16) : 0;
  const pulse = 0.5 + 0.5 * Math.sin(frame / 8);
  return (
    <Pop delay={delay} from="bottom" dist={44} preset="snappy" s={0.9}>
      <div
        style={{
          width: 392,
          height: 232,
          borderRadius: 28,
          boxSizing: "border-box",
          padding: 22,
          position: "relative",
          background: `linear-gradient(160deg, ${theme.alpha.white(0.09 * (1 - e))}, ${theme.alpha.white(0.025 * (1 - e))})`,
          border: e > 0.5 ? `2px dashed ${c.hero}` : `1px solid ${c.line}`,
          boxShadow: e > 0.5 ? `0 0 ${24 + pulse * 30}px ${theme.colors.glow}` : undefined,
        }}
      >
        <div style={{ opacity: 1 - e }}>
          <div style={{ height: 96, borderRadius: 18, background: `${theme.alpha.white(0.08)}`, marginBottom: 20 }} />
          <Skel widths={[250, 160]} h={13} gap={10} delay={delay + 8} />
        </div>
        {empty && (
          <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 14, opacity: e }}>
            <Icon name="help" size={64} color={c.hero} stroke={1.6} />
            <Chip text="demo" size={26} solid />
          </div>
        )}
      </div>
    </Pop>
  );
};

export const S05Question: React.FC = () => {
  const T = T5;
  const t12 = T.t(12);
  const t13 = T.t(13);
  const c = useC();
  const br = useBreathe(120, 0.007);
  const frame = useCurrentFrame();
  return (
    <SceneShell tone="dark" bg="spot">
      <AbsoluteFill>
        <div style={{ position: "absolute", left: 130, top: 170 }}>
          <Pop delay={0} from="left" dist={60} preset="bouncy" s={0.7} origin="0% 50%">
            <Chip text="Q1" size={46} solid />
          </Pop>
        </div>
        <div style={{ position: "absolute", left: 130, top: 285 }}>
          <Words text="ভাই, আপনি জানতে চেয়েছিলেন" size={70} delay={4} per={4} maxWidth={760} dim={[0, 1, 2]} hero={[3]} />
        </div>
        <div style={{ position: "absolute", left: 130, top: 520 }}>
          <Words text="আমার website এ আগের project" size={64} delay={t12 + 2} per={4} maxWidth={760} hero={[1]} dim={[0, 2, 3]} />
        </div>
        <div style={{ position: "absolute", left: 130, top: 720 }}>
          <Words text="demo কেন নেই?" size={104} delay={t13 + 2} per={5} maxWidth={800} mark={[0]} grad={[1, 2]} />
        </div>

        {/* ব্রাউজার উইন্ডো */}
        <div style={{ position: "absolute", left: 960, top: 190, width: 880, transform: `scale(${br})`, transformOrigin: "50% 50%" }}>
          <Pop delay={t12 - 2} from="right" dist={200} preset="smooth" s={0.92}>
            <Glass w={880} h={700} r={40} strong>
              <div style={{ height: 78, padding: "0 30px", display: "flex", alignItems: "center", gap: 14, borderBottom: `1px solid ${c.line}` }}>
                {[0, 1, 2].map((i) => (
                  <div key={i} style={{ width: 15, height: 15, borderRadius: 15, background: c.lineStrong }} />
                ))}
                <div style={{ flex: 1, height: 38, borderRadius: 38, border: `1px solid ${c.line}`, margin: "0 0 0 24px", display: "flex", alignItems: "center", padding: "0 20px", gap: 14 }}>
                  <Icon name="globe" size={22} color={c.dim} />
                  <Skel widths={[210]} h={11} delay={t12 + 6} />
                </div>
              </div>
              <div style={{ padding: "34px 36px", display: "grid", gridTemplateColumns: "repeat(2, 392px)", gap: 28 }}>
                <ProjectCard delay={t12 + 8} />
                <ProjectCard delay={t12 + 13} />
                <ProjectCard delay={t12 + 18} />
                <ProjectCard delay={t12 + 23} empty emptyAt={t13 + 6} />
              </div>
            </Glass>
          </Pop>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
