import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { CL, Pop, Words, ramp, useSp } from "../components/Motion";
import { Icon } from "../components/Icons";
import { Avatar, Chip, Glass, Skel } from "../components/Ui";
import { useC } from "../components/Tone";
import { SfxEvent } from "../components/Sfx";
import { Timer, makeTimer } from "../timing";
import { theme } from "../theme";

export const T3 = makeTimer(6, 8);
export const sfx3 = (T: Timer): SfxEvent[] => [
  { at: T.from + 6, name: "pluck", vol: 0.8 },
  { at: T.from + 34, name: "pop" },
  { at: T.from + T.t(7) + 6, name: "pop", rate: 1.1 },
  { at: T.from + T.t(7) + 40, name: "click", vol: 0.8 },
];

const Sun: React.FC = () => {
  const frame = useCurrentFrame();
  const c = useC();
  const rise = useSp(0, "slow");
  const y = interpolate(rise, [0, 1], [380, 0]);
  const rays = 14;
  return (
    <div style={{ position: "absolute", left: 1500, top: 110 + y, width: 300, height: 300, opacity: Math.min(1, rise * 2) }}>
      <svg width={300} height={300} viewBox="-150 -150 300 300" style={{ transform: `rotate(${frame * 0.35}deg)` }}>
        {Array.from({ length: rays }).map((_, i) => {
          const p = ramp(frame, 8 + i * 1.5, 30 + i * 1.5);
          const a = (i / rays) * Math.PI * 2;
          const r1 = 92, r2 = 92 + (i % 2 ? 26 : 44) * p;
          return (
            <line key={i} x1={Math.cos(a) * r1} y1={Math.sin(a) * r1} x2={Math.cos(a) * r2} y2={Math.sin(a) * r2} stroke={c.hero} strokeWidth={9} strokeLinecap="round" />
          );
        })}
        <circle r={66} fill={c.hero} />
      </svg>
    </div>
  );
};

const HistoryRow: React.FC<{ i: number; delay: number; active: boolean }> = ({ i, delay, active }) => {
  const c = useC();
  return (
    <Pop delay={delay} from="bottom" dist={26} preset="snappy">
      <div
        style={{
          height: 78,
          display: "flex",
          alignItems: "center",
          gap: 22,
          padding: "0 26px",
          borderRadius: 24,
          background: active ? c.hero : "transparent",
          border: `1px solid ${active ? "transparent" : c.line}`,
        }}
      >
        <Avatar size={46} icon={i % 2 ? "bot" : "user"} solid={active} />
        <div style={{ flex: 1 }}>
          <Skel widths={[260 - (i % 3) * 40, 150]} h={12} gap={9} delay={delay + 6} hero={active} />
        </div>
        <div style={{ width: 54, height: 12, borderRadius: 12, background: active ? `${theme.alpha.text(0.35)}` : c.line }} />
      </div>
    </Pop>
  );
};

const S03MorningContent: React.FC = () => {
  const T = T3;
  const t7 = T.t(7);
  const frame = useCurrentFrame();
  const c = useC();
  const scan = ramp(frame, 44, 86, theme.ease.inOut);
  const panelShift = useSp(t7, "smooth");
  const px = interpolate(panelShift, [0, 1], [0, 0]);
  return (
    <>
      <AbsoluteFill>
        <Sun />

        {/* ফেজ A: ঘুম থেকে উঠে history */}
        <div style={{ position: "absolute", left: 130, top: 120 }}>
          <Words text="সকালে ঘুম থেকে উঠে" size={92} delay={2} per={4} hero={[0]} out={t7 - 4} />
        </div>
        <div style={{ position: "absolute", left: 130, top: 262 }}>
          <Words text="history দেখে বুঝলাম" size={92} delay={22} per={5} mark={[0]} dim={[2]} out={t7 - 4} />
        </div>

        {/* history প্যানেল */}
        <div style={{ position: "absolute", left: 130 + px, top: 470, width: 800 }}>
          <Pop delay={14} from="bottom" dist={90} preset="smooth" s={0.94}>
            <Glass w={800} h={540} r={40} pad={26}>
              <div style={{ display: "flex", alignItems: "center", gap: 18, padding: "4px 12px 18px" }}>
                <Icon name="history" size={40} color={c.hero} />
                <div style={{ fontFamily: theme.fonts.main, fontWeight: theme.weight.strong, fontSize: 34, color: c.fg, lineHeight: 1.3 }}>History</div>
              </div>
              <div style={{ position: "relative", display: "flex", flexDirection: "column", gap: 12 }}>
                {[0, 1, 2, 3, 4].map((i) => (
                  <HistoryRow key={i} i={i} delay={28 + i * 5} active={i === 2 && scan > 0.55} />
                ))}
                {/* স্ক্যান রেখা */}
                <div
                  style={{
                    position: "absolute",
                    left: 0,
                    right: 0,
                    top: scan * 380 - 6,
                    height: 3,
                    borderRadius: 3,
                    background: c.hero,
                    opacity: scan > 0 && scan < 1 ? 0.8 : 0,
                  }}
                />
              </div>
            </Glass>
          </Pop>
        </div>

        {/* ফেজ B: client টের পায়নি */}
        <div style={{ position: "absolute", left: 1010, top: 380 }}>
          <Words text="client একদমই" size={96} delay={t7 + 2} per={5} maxWidth={820} mark={[0]} />
        </div>
        <div style={{ position: "absolute", left: 1010, top: 520 }}>
          <Words text="টের পায়নি" size={110} delay={t7 + 14} per={5} grad={[0, 1]} maxWidth={820} />
        </div>
        <div style={{ position: "absolute", left: 1010, top: 718 }}>
          <Pop delay={t7 + 22} from="bottom" dist={60} preset="bouncy" s={0.9}>
            <Glass w={760} h={250} r={38} pad={30}>
              <div style={{ display: "flex", alignItems: "center", gap: 28, height: "100%" }}>
                <div style={{ position: "relative" }}>
                  <Avatar size={104} icon="user" ring />
                  <div style={{ position: "absolute", right: -22, top: -34 }}>
                    <Pop delay={t7 + 36} from="bottom" dist={20} preset="bouncy" s={0.4}>
                      <div style={{ width: 62, height: 62, borderRadius: 62, background: c.hero, display: "flex", alignItems: "center", justifyContent: "center" }}>
                        <Icon name="help" size={36} color={c.onHero} />
                      </div>
                    </Pop>
                  </div>
                </div>
                <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 20 }}>
                  <Skel widths={[300, 210]} h={14} delay={t7 + 30} />
                  <div style={{ display: "flex", justifyContent: "flex-end" }}>
                    <Chip text="AI এর সাথে chat" icon="bot" size={26} solid />
                  </div>
                </div>
              </div>
            </Glass>
          </Pop>
        </div>
      </AbsoluteFill>
    </>
  );
};

export const S03Morning: React.FC = () => (
  <SceneShell tone="light" bg="light">
    <S03MorningContent />
  </SceneShell>
);
