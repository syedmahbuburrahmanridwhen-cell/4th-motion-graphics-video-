import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { Pop, Words, ramp, useSp } from "../components/Motion";
import { Icon } from "../components/Icons";
import { Chip } from "../components/Ui";
import { useC } from "../components/Tone";
import { SfxEvent } from "../components/Sfx";
import { Timer, makeTimer } from "../timing";
import { theme } from "../theme";

export const T6B = makeTimer(16, 18);
export const sfx6b = (T: Timer): SfxEvent[] => [
  { at: T.from + 24, name: "pop" },
  { at: T.from + 40, name: "pop", rate: 1.08, vol: 0.85 },
  { at: T.from + T.t(17) + 6, name: "pluck", vol: 0.8 },
];

const NX = [400, 960, 1520];
const NY = 450;

const Connector: React.FC<{ x1: number; x2: number; delay: number }> = ({ x1, x2, delay }) => {
  const frame = useCurrentFrame();
  const c = useC();
  const p = ramp(frame, delay, delay + 20);
  const dotX = x1 + ((frame * 5) % (x2 - x1));
  return (
    <>
      <div style={{ position: "absolute", left: x1, top: NY - 2, width: (x2 - x1) * p, height: 0, borderTop: `3px dashed ${c.dim}` }} />
      {p > 0.98 && <div style={{ position: "absolute", left: dotX - 7, top: NY - 8, width: 14, height: 14, borderRadius: 14, background: c.hero }} />}
    </>
  );
};

const Node: React.FC<{ x: number; r: number; icon: string; delay: number; solid?: boolean; label?: string; spin?: boolean }> = ({ x, r, icon, delay, solid, label, spin }) => {
  const frame = useCurrentFrame();
  const c = useC();
  return (
    <div style={{ position: "absolute", left: x - r - 20, top: NY - r, width: 2 * r + 40, display: "flex", flexDirection: "column", alignItems: "center", gap: 26 }}>
      <Pop delay={delay} from="bottom" dist={50} preset="bouncy" s={0.5}>
        <div
          style={{
            width: 2 * r,
            height: 2 * r,
            borderRadius: 2 * r,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            background: solid ? c.hero : `${theme.alpha.white(0.08)}`,
            border: `1.5px solid ${solid ? "transparent" : c.lineStrong}`,
            boxShadow: solid ? `0 0 90px ${theme.colors.glow}` : undefined,
          }}
        >
          <Icon name={icon} size={r * 0.95} color={solid ? c.onHero : c.fg} stroke={1.6} style={{ transform: spin ? `rotate(${frame * 3.2}deg)` : undefined }} />
        </div>
      </Pop>
      {label && (
        <Pop delay={delay + 8} from="bottom" dist={20}>
          <Chip text={label} size={30} />
        </Pop>
      )}
    </div>
  );
};

export const S06bProcess: React.FC = () => {
  const T = T6B;
  const t17 = T.t(17);
  const frame = useCurrentFrame();
  const c = useC();
  const loop = ramp(frame, t17 + 10, t17 + 50, theme.ease.inOut);
  const len = 1300;
  return (
    <SceneShell tone="dark" bg="mesh">
      <AbsoluteFill>
        <div style={{ position: "absolute", left: 0, right: 0, top: 90, display: "flex", justifyContent: "center" }}>
          <Words text="এখন সেগুলো demo হিসেবে দেখাতে গেলে" size={74} delay={2} per={4} align="center" dim={[0, 1, 3, 4]} hero={[2]} />
        </div>

        <Connector x1={NX[0] + 100} x2={NX[1] - 100} delay={26} />
        <Connector x1={NX[1] + 100} x2={NX[2] - 140} delay={38} />
        <Node x={NX[0]} r={92} icon="file" delay={16} label="আগের কাজ" />
        <Node x={NX[1]} r={92} icon="play" delay={28} label="demo" />
        <Node x={NX[2]} r={128} icon="refresh" delay={t17} solid spin />

        {/* ফিরতি লুপ: আবার প্রথম থেকে */}
        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
          <path
            d={`M ${NX[2]} ${NY + 150} C ${NX[2]} 760, ${NX[0]} 760, ${NX[0]} ${NY + 190}`}
            fill="none"
            stroke={c.hero}
            strokeWidth={4}
            strokeLinecap="round"
            strokeDasharray={`${len * loop} ${len}`}
            opacity={0.9}
          />
        </svg>

        <div style={{ position: "absolute", left: 0, right: 0, top: 815, display: "flex", justifyContent: "center" }}>
          <Words text="নতুন করে আবার বানাতে হবে" size={96} delay={t17 + 4} per={5} align="center" mark={[0, 1]} hero={[2, 3, 4]} />
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
