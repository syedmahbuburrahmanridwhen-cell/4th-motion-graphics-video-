import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { Pop, Words, ramp, useSp } from "../components/Motion";
import { Icon } from "../components/Icons";
import { Chip, Cursor, Glass, Ripple, Spark } from "../components/Ui";
import { useC } from "../components/Tone";
import { SfxEvent } from "../components/Sfx";
import { Timer, makeTimer } from "../timing";
import { theme } from "../theme";

export const T9C = makeTimer(30);
export const sfx9c = (T: Timer): SfxEvent[] => [
  { at: T.from + 18, name: "pluck", vol: 0.9 },
  { at: T.from + 62, name: "click", vol: 0.9 },
  { at: T.from + T.t(31) + 40, name: "click", vol: 0.9, rate: 1.08 },
  { at: T.from + T.t(31, 0.72), name: "chime", vol: 0.9 },
];

const RX = 930;

export const S09cCta: React.FC = () => {
  const T = T9C;
  const t31 = T.t(31);
  const thanks = T.t(31, 0.72);
  const frame = useCurrentFrame();
  const c = useC();
  const under = ramp(frame, 40, 70, theme.ease.inOut);
  const cp = ramp(frame, 44, 66, theme.ease.inOut);
  const cx = interpolate(cp, [0, 1], [1700, 1210]);
  const cy = interpolate(cp, [0, 1], [780, 560]);
  const cursor2 = ramp(frame, t31 + 16, t31 + 38, theme.ease.inOut);
  return (
    <SceneShell tone="dark" bg="globe" globe={{ cx: 1400, cy: 540, R: 560, op: 0.28 }} exit={false}>
      <AbsoluteFill>
        <div style={{ position: "absolute", left: RX, top: 150 }}>
          <Words text="visit করতে পারেন" size={76} delay={4} per={5} dim={[1, 2]} hero={[0]} />
        </div>

        {/* URL */}
        <div style={{ position: "absolute", left: RX, top: 290 }}>
          <Pop delay={14} from="right" dist={90} preset="smooth" s={0.9}>
            <Glass r={44} strong pad={0} style={{ display: "inline-block" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 26, padding: "34px 52px 30px 40px" }}>
                <Icon name="globe" size={72} color={c.hero} stroke={1.5} />
                <div style={{ position: "relative" }}>
                  <div style={{ fontFamily: theme.fonts.main, fontWeight: theme.weight.heavy, fontSize: 70, color: c.hero, lineHeight: 1.2, letterSpacing: 0, textShadow: `0 0 50px ${theme.colors.glow}` }}>
                    ridwan.netlify.app
                  </div>
                  <div style={{ position: "absolute", left: 0, bottom: -6, height: 5, borderRadius: 5, width: `${under * 100}%`, background: c.hero }} />
                </div>
              </div>
            </Glass>
          </Pop>
        </div>

        {/* Visit বাটন */}
        <div style={{ position: "absolute", left: RX, top: 500 }}>
          <Pop delay={30} from="bottom" dist={40} preset="bouncy" s={0.8}>
            <Chip text="Visit website" icon="link" size={42} solid />
          </Pop>
        </div>
        {frame > 40 && (
          <div style={{ position: "absolute", left: cx, top: cy, opacity: ramp(frame, 40, 48) * (1 - ramp(frame, 74, 86)) }}>
            <Cursor size={54} />
            <div style={{ position: "absolute", left: 6, top: 6 }}>
              <Ripple at={62} size={130} />
            </div>
          </div>
        )}

        {/* অথবা সরাসরি inbox */}
        <div style={{ position: "absolute", left: RX, top: 650 }}>
          <Words text="অথবা সরাসরি আমাকে" size={64} delay={t31} per={4} dim={[0, 1]} hero={[2]} out={thanks - 4} />
        </div>
        <div style={{ position: "absolute", left: RX, top: 770 }}>
          <Pop delay={t31 + 10} out={thanks - 4} from="bottom" dist={40} preset="bouncy" s={0.8}>
            <Chip text="inbox করুন" icon="mail" size={50} solid />
          </Pop>
        </div>
        {frame > t31 + 14 && (
          <div style={{ position: "absolute", left: interpolate(cursor2, [0, 1], [1750, 1190]), top: interpolate(cursor2, [0, 1], [950, 830]), opacity: ramp(frame, t31 + 14, t31 + 22) * (1 - ramp(frame, thanks - 6, thanks)) }}>
            <Cursor size={54} />
            <div style={{ position: "absolute", left: 6, top: 6 }}>
              <Ripple at={t31 + 40} size={130} />
            </div>
          </div>
        )}

        {/* ধন্যবাদ */}
        <div style={{ position: "absolute", left: RX, top: 640 }}>
          <div style={{ position: "absolute", left: 640, top: 20 }}>
            <Pop delay={thanks + 2} from="none" preset="bouncy" s={0.3}>
              <div style={{ position: "relative", width: 200, height: 200 }}>
                <Spark size={200} delay={thanks + 4} rays={12} />
                <div style={{ position: "absolute", left: 66, top: 66 }}>
                  <Icon name="sparkles" size={68} color={c.hero} stroke={1.6} />
                </div>
              </div>
            </Pop>
          </div>
          <Words text="ধন্যবাদ" size={180} delay={thanks} per={6} hero={[0]} style={{ textShadow: `0 0 60px ${theme.colors.glow}` }} />
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
