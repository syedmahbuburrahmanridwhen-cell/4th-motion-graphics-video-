import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { CL, Pop, Words, ramp, useBreathe, useSp } from "../components/Motion";
import { Icon } from "../components/Icons";
import { Chip, Glass, Skel } from "../components/Ui";
import { useC } from "../components/Tone";
import { SfxEvent } from "../components/Sfx";
import { Timer, makeTimer } from "../timing";
import { theme } from "../theme";

export const T8 = makeTimer(21, 24);
export const sfx8 = (T: Timer): SfxEvent[] => [
  { at: T.from + 6, name: "pop", vol: 0.9 },
  { at: T.from + T.t(22) + 8, name: "pop" },
  { at: T.from + T.t(23) + 4, name: "pop", rate: 1.06 },
  { at: T.from + T.t(23) + 22, name: "click", vol: 0.8 },
  { at: T.from + T.t(23) + 44, name: "click", vol: 0.8, rate: 1.1 },
];

const Toggle: React.FC<{ on: number }> = ({ on }) => {
  const c = useC();
  return (
    <div style={{ width: 92, height: 50, borderRadius: 50, background: on > 0.5 ? c.hero : c.lineStrong, position: "relative" }}>
      <div style={{ position: "absolute", top: 5, left: 5 + on * 42, width: 40, height: 40, borderRadius: 40, background: on > 0.5 ? c.onHero : c.surface }} />
    </div>
  );
};

const Tile: React.FC<{ icon: string; label: string; delay: number; on: number; w: number }> = ({ icon, label, delay, on, w }) => {
  const c = useC();
  return (
    <Pop delay={delay} from="bottom" dist={70} preset="bouncy" s={0.84}>
      <Glass w={w} h={310} r={42} pad={34}>
        <div style={{ display: "flex", flexDirection: "column", height: "100%", justifyContent: "space-between" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div style={{ width: 92, height: 92, borderRadius: 30, background: c.hero, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Icon name={icon} size={50} color={c.onHero} stroke={1.7} />
            </div>
            <Toggle on={on} />
          </div>
          <div>
            <div style={{ fontFamily: theme.fonts.main, fontWeight: theme.weight.heavy, fontSize: 58, color: c.fg, lineHeight: 1.3, marginBottom: 14 }}>{label}</div>
            <Skel widths={[w - 200, w - 300]} h={13} gap={10} delay={delay + 10} />
          </div>
        </div>
      </Glass>
    </Pop>
  );
};

const S08ChargeContent: React.FC = () => {
  const T = T8;
  const t22 = T.t(22);
  const t23 = T.t(23);
  const frame = useCurrentFrame();
  const c = useC();
  const br = useBreathe(130, 0.006);
  const onF = ramp(frame, t23 + 20, t23 + 30);
  const onD = ramp(frame, t23 + 42, t23 + 52);
  const knob = 0.18 + 0.34 * onF + 0.3 * onD;
  const knobS = ramp(frame, t22 + 10, t22 + 30) * knob + (1 - ramp(frame, t22 + 10, t22 + 30)) * 0.18;
  const slide = useSp(t22, "smooth");
  return (
    <>
      <AbsoluteFill>
        {/* ফেজ A: Q2 স্টেটমেন্ট কার্ড */}
        <div style={{ position: "absolute", left: 130, top: 190 }}>
          <Pop delay={0} out={t22 - 4} from="left" dist={60} preset="bouncy" s={0.7} origin="0% 50%">
            <Chip text="Q2" size={52} solid />
          </Pop>
        </div>
        <div style={{ position: "absolute", left: 130, top: 330 }}>
          <Words text="এ ধরনের website বানাতে" size={96} delay={3} per={4} maxWidth={1100} dim={[0, 1]} hero={[2]} out={t22 - 4} />
        </div>
        <div style={{ position: "absolute", left: 130, top: 480 }}>
          <Words text="আমি কত charge করি?" size={132} delay={14} per={5} maxWidth={1560} mark={[1]} hero={[0, 2, 3]} out={t22 - 4} />
        </div>
        <div style={{ position: "absolute", left: 1540, top: 120 }}>
          <Pop delay={10} out={t22 - 4} from="bottom" dist={60} preset="bouncy" s={0.5}>
            <div style={{ transform: `rotate(${-14 + Math.sin(frame / 16) * 5}deg)` }}>
              <Icon name="tag" size={250} color={c.hero} stroke={1.2} />
            </div>
          </Pop>
        </div>

        {/* ফেজ B: budget নির্ভর করে */}
        <div style={{ position: "absolute", left: 130, top: 110 }}>
          <Words text="budget পুরোপুরি নির্ভর করে" size={84} delay={t22 + 2} per={4} maxWidth={1500} mark={[0]} dim={[1, 2]} />
        </div>

        <div style={{ position: "absolute", left: 130, top: 300, transform: `scale(${br})`, transformOrigin: "0% 0%" }}>
          <div style={{ display: "flex", gap: 36, alignItems: "stretch" }}>
            <div style={{ display: "flex", flexDirection: "column", gap: 36 }}>
              <Tile icon="layers" label="feature" delay={t23 + 2} on={onF} w={640} />
              <Tile icon="pen" label="design" delay={t23 + 10} on={onD} w={640} />
            </div>
            {/* budget টাইল */}
            <Pop delay={t22 + 14} from="right" dist={90} preset="smooth" s={0.9}>
              <Glass w={900} h={656} r={46} pad={44} strong>
                <div style={{ display: "flex", flexDirection: "column", height: "100%", justifyContent: "space-between" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 22 }}>
                    <Icon name="slider" size={64} color={c.hero} stroke={1.6} />
                    <div style={{ fontFamily: theme.fonts.main, fontWeight: theme.weight.heavy, fontSize: 84, color: c.hero, lineHeight: 1.3 }}>budget</div>
                  </div>
                  {/* স্লাইডার */}
                  <div style={{ position: "relative", height: 24, borderRadius: 24, background: c.line, margin: "0 6px" }}>
                    <div style={{ width: `${knobS * 100}%`, height: "100%", borderRadius: 24, background: c.hero }} />
                    <div style={{ position: "absolute", left: `${knobS * 100}%`, top: -22, width: 68, height: 68, borderRadius: 68, background: c.hero, border: `8px solid ${c.surface}`, boxSizing: "border-box", transform: "translateX(-34px)", boxShadow: `0 10px 30px ${c.shadow}` }} />
                  </div>
                  <div style={{ display: "flex", gap: 24 }}>
                    <Skel widths={[300, 220, 160]} h={16} gap={14} delay={t22 + 24} />
                  </div>
                </div>
              </Glass>
            </Pop>
          </div>
        </div>
        <div style={{ position: "absolute", left: 130, top: 1010 }} />
      </AbsoluteFill>
    </>
  );
};

export const S08Charge: React.FC = () => (
  <SceneShell tone="light" bg="light">
    <S08ChargeContent />
  </SceneShell>
);
