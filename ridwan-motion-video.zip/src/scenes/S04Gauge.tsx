import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { CL, Pop, Words, ramp, useBreathe, useSp } from "../components/Motion";
import { Icon } from "../components/Icons";
import { Chip, Glass } from "../components/Ui";
import { useC } from "../components/Tone";
import { SfxEvent } from "../components/Sfx";
import { Timer, makeTimer } from "../timing";
import { theme } from "../theme";

export const T4 = makeTimer(8, 11);
export const sfx4 = (T: Timer): SfxEvent[] => [
  { at: T.from + 12, name: "pop" },
  { at: T.from + T.t(9) + 14, name: "click", vol: 0.8 },
  { at: T.from + T.t(10) + 8, name: "pop", rate: 1.1 },
  { at: T.from + T.t(10) + 52, name: "chime", vol: 0.8 },
];

const R = 210;
const SW = 34;
const CIRC = 2 * Math.PI * R;

const Gauge: React.FC<{ t9: number; out: number }> = ({ t9, out }) => {
  const frame = useCurrentFrame();
  const c = useC();
  const fill = ramp(frame, 12, t9 + 20, theme.ease.soft) * 0.74;
  const stall = ramp(frame, t9 + 20, t9 + 34);
  const shake = frame > t9 + 20 && frame < t9 + 34 ? Math.sin(frame * 2.4) * (1 - stall) * 9 : 0;
  const ang = fill * Math.PI * 2 - Math.PI / 2;
  const bx = 300 + Math.cos(ang) * R;
  const by = 300 + Math.sin(ang) * R;
  const spin = frame * 0.25;
  return (
    <Pop delay={4} out={out} from="left" dist={140} preset="smooth" s={0.9}>
      <div style={{ position: "relative", width: 600, height: 600, transform: `translateX(${shake}px)` }}>
        <svg width={600} height={600} viewBox="0 0 600 600">
          {/* লক্ষ্য: পূর্ণ বৃত্ত (শতভাগ) */}
          <circle cx={300} cy={300} r={R + 44} fill="none" stroke={c.dim} strokeWidth={2} strokeDasharray="6 14" opacity={0.7} transform={`rotate(${spin} 300 300)`} />
          <circle cx={300} cy={300} r={R} fill="none" stroke={c.line} strokeWidth={SW} />
          <circle
            cx={300}
            cy={300}
            r={R}
            fill="none"
            stroke={c.hero}
            strokeWidth={SW}
            strokeLinecap="round"
            strokeDasharray={`${CIRC * fill} ${CIRC}`}
            transform="rotate(-90 300 300)"
            style={{ filter: `drop-shadow(0 0 18px ${theme.colors.glow})` }}
          />
        </svg>
        {/* কেন্দ্রে আইকন */}
        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Icon name="chat" size={150} color={c.fg} stroke={1.3} />
        </div>
        {/* অসম্পূর্ণ ব্যাজ */}
        <div style={{ position: "absolute", left: bx - 40, top: by - 40, opacity: stall, transform: `scale(${0.4 + 0.6 * stall})` }}>
          <div style={{ width: 80, height: 80, borderRadius: 80, background: c.hero, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Icon name="x" size={44} color={c.onHero} stroke={2.6} />
          </div>
        </div>
      </div>
    </Pop>
  );
};

const VideoFrame: React.FC<{ at: number }> = ({ at }) => {
  const frame = useCurrentFrame();
  const c = useC();
  const br = useBreathe(100, 0.01);
  const prog = ramp(frame, at + 40, at + 170, theme.ease.inOut);
  const blink = Math.sin(frame / 6) > 0 ? 1 : 0.25;
  return (
    <div style={{ position: "absolute", left: 960 - 470, top: 270, width: 940, transform: `scale(${br})` }}>
      <Pop delay={at} from="bottom" dist={120} preset="smooth" s={0.82}>
        <Glass w={940} h={520} r={44} strong>
          <div style={{ position: "absolute", left: 34, top: 30, display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{ width: 18, height: 18, borderRadius: 18, background: c.hero, opacity: blink }} />
            <div style={{ fontFamily: theme.fonts.main, fontWeight: theme.weight.strong, fontSize: 26, color: c.fg, lineHeight: 1.3 }}>REC</div>
          </div>
          <div style={{ position: "absolute", right: 34, top: 28 }}>
            <Chip text="video" icon="video" size={24} />
          </div>
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Pop delay={at + 12} from="none" preset="bouncy" s={0.3}>
              <div style={{ width: 168, height: 168, borderRadius: 168, background: c.hero, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 0 90px ${theme.colors.glow}` }}>
                <Icon name="play" size={72} color={c.onHero} fill={c.onHero} stroke={1} style={{ marginLeft: 8 }} />
              </div>
            </Pop>
          </div>
          {/* স্ক্রাবার */}
          <div style={{ position: "absolute", left: 44, right: 44, bottom: 40, height: 10, borderRadius: 10, background: c.line }}>
            <div style={{ width: `${prog * 100}%`, height: "100%", borderRadius: 10, background: c.hero }} />
            <div style={{ position: "absolute", left: `${prog * 100}%`, top: -7, width: 24, height: 24, borderRadius: 24, background: c.hero, transform: "translateX(-12px)" }} />
          </div>
        </Glass>
      </Pop>
    </div>
  );
};

export const S04Gauge: React.FC = () => {
  const T = T4;
  const t9 = T.t(9);
  const t10 = T.t(10);
  const word = T.t(8, 0.76);
  const hold = T.t(9, 0.34);
  return (
    <SceneShell tone="dark" bg="mesh">
      <AbsoluteFill>
        {/* ফেজ A */}
        <div style={{ position: "absolute", left: 90, top: 240 }}>
          <Gauge t9={t9} out={t10 - 6} />
        </div>
        <div style={{ position: "absolute", left: 800, top: 270 }}>
          <Words text="কিন্তু AI এর উত্তরে" size={72} delay={4} per={4} dim={[0, 1, 2]} hero={[3]} out={t10 - 6} maxWidth={1000} />
        </div>
        <div style={{ position: "absolute", left: 800, top: 410 }}>
          <Words text="শতভাগ" size={168} delay={word} per={4} mark={[0]} out={t10 - 6} />
        </div>
        <div style={{ position: "absolute", left: 800, top: 620 }}>
          <Words text="satisfied" size={126} delay={t9} per={4} hero={[0]} out={t10 - 6} />
        </div>
        <div style={{ position: "absolute", left: 800, top: 782 }}>
          <Pop delay={hold} out={t10 - 6} from="bottom" dist={34} preset="bouncy" s={0.8}>
            <Chip text="হতে পারেনি" icon="x" size={46} />
          </Pop>
        </div>

        {/* ফেজ B: সরাসরি video-তে */}
        <div style={{ position: "absolute", left: 0, right: 0, top: 70, display: "flex", justifyContent: "center" }}>
          <Words text="সরাসরি video-তেই" size={104} delay={t10 + 2} per={5} align="center" hero={[1]} grad={[1]} />
        </div>
        <VideoFrame at={t10 + 6} />
        <div style={{ position: "absolute", left: 0, right: 0, top: 850, display: "flex", justifyContent: "center" }}>
          <Words text="উত্তরগুলো দিয়ে দিই" size={72} delay={t10 + 26} per={4} align="center" dim={[0]} hero={[1, 2, 3]} />
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
