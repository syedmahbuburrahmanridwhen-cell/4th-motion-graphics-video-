import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { CL, Pop, Words, ramp, useSp } from "../components/Motion";
import { Icon } from "../components/Icons";
import { Avatar, Chip, Glass, Skel } from "../components/Ui";
import { useC } from "../components/Tone";
import { SfxEvent } from "../components/Sfx";
import { Timer, makeTimer } from "../timing";
import { theme } from "../theme";

export const T1 = makeTimer(1, 4);
export const sfx1 = (T: Timer): SfxEvent[] => [
  { at: T.from + 50, name: "thud", vol: 0.7 },
  { at: T.from + T.t(2) + 3, name: "pop" },
  { at: T.from + T.t(3) + 5, name: "pop", rate: 0.9, vol: 0.9 },
];

const DIGIT = 300;

const Digit: React.FC<{ target: number; delay: number }> = ({ target, delay }) => {
  const frame = useCurrentFrame();
  const c = useC();
  const H = Math.round(DIGIT * 1.18);
  const p = ramp(frame, delay, delay + 46, theme.ease.out);
  const y = -(10 + target) * H * p;
  const blur = Math.max(0, (1 - p) * 14);
  return (
    <div style={{ width: Math.round(DIGIT * 0.64), height: H, overflow: "hidden", position: "relative" }}>
      <div style={{ transform: `translateY(${y}px)`, filter: blur > 0.4 ? `blur(${blur}px)` : undefined }}>
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            style={{
              height: H,
              lineHeight: `${H}px`,
              textAlign: "center",
              fontFamily: theme.fonts.main,
              fontWeight: theme.weight.heavy,
              fontSize: DIGIT,
              color: c.hero,
              fontVariantNumeric: "tabular-nums",
            }}
          >
            {i % 10}
          </div>
        ))}
      </div>
    </div>
  );
};

const Clock: React.FC<{ t2: number }> = ({ t2 }) => {
  const frame = useCurrentFrame();
  const c = useC();
  const intro = useSp(0, "bouncy");
  const move = useSp(t2, "smooth");
  const mx = interpolate(move, [0, 1], [0, -640]);
  const my = interpolate(move, [0, 1], [0, -300]);
  const sc = interpolate(move, [0, 1], [1, 0.4]) * (0.9 + 0.1 * intro);
  const blink = 0.55 + 0.45 * Math.sin(frame / 7);
  const H = Math.round(DIGIT * 1.18);
  return (
    <div
      style={{
        position: "absolute",
        left: 960 - 460,
        top: 500 - H / 2,
        width: 920,
        height: H,
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        transform: `translate(${mx}px, ${my}px) scale(${sc})`,
        opacity: Math.min(1, intro * 1.6),
        filter: `drop-shadow(0 0 40px ${theme.colors.glow})`,
      }}
    >
      <Digit target={0} delay={0} />
      <Digit target={3} delay={6} />
      <div
        style={{
          width: 60,
          textAlign: "center",
          fontFamily: theme.fonts.main,
          fontWeight: theme.weight.heavy,
          fontSize: DIGIT,
          lineHeight: `${H}px`,
          color: c.hero,
          opacity: blink,
          transform: "translateY(-14px)",
        }}
      >
        :
      </div>
      <Digit target={0} delay={12} />
      <Digit target={0} delay={18} />
    </div>
  );
};

const Moon: React.FC<{ t3: number }> = ({ t3 }) => {
  const frame = useCurrentFrame();
  const c = useC();
  const intro = useSp(16, "bouncy");
  const m3 = useSp(t3, "smooth");
  const size = interpolate(m3, [0, 1], [118, 400]);
  const x = interpolate(m3, [0, 1], [1640, 1390]);
  const y = interpolate(m3, [0, 1], [200, 520]) + Math.sin(frame / 34) * 8;
  const rot = interpolate(m3, [0, 1], [-18, -8]) + Math.sin(frame / 50) * 3;
  return (
    <div
      style={{
        position: "absolute",
        left: x - size / 2,
        top: y - size / 2,
        width: size,
        height: size,
        opacity: Math.min(1, intro * 1.5),
        transform: `scale(${0.4 + 0.6 * intro}) rotate(${rot}deg)`,
        filter: `drop-shadow(0 0 ${size * 0.22}px ${theme.colors.glow})`,
      }}
    >
      <Icon name="moon" size={size} color={c.hero} fill={c.hero} stroke={1} />
    </div>
  );
};

const Zs: React.FC<{ t3: number }> = ({ t3 }) => {
  const frame = useCurrentFrame();
  const c = useC();
  const start = t3 + 22;
  if (frame < start) return null;
  return (
    <>
      {[0, 1, 2].map((i) => {
        const q = (((frame - start - i * 26) % 84) + 84) % 84;
        if (frame - start - i * 26 < 0) return null;
        const p = q / 84;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: 1560 + p * 110,
              top: 330 - p * 210,
              fontFamily: theme.fonts.main,
              fontWeight: theme.weight.heavy,
              fontSize: 54 + p * 62,
              color: c.hero,
              opacity: Math.sin(Math.PI * p) * 0.95,
              transform: `rotate(${-10 + p * 22}deg)`,
              textShadow: `0 0 30px ${theme.colors.glow}`,
            }}
          >
            Z
          </div>
        );
      })}
    </>
  );
};

const Notification: React.FC<{ at: number; out: number }> = ({ at, out }) => {
  const frame = useCurrentFrame();
  const c = useC();
  return (
    <div style={{ position: "absolute", left: 960 - 420, top: 580, width: 840, transform: "scale(1.12)", transformOrigin: "50% 0%" }}>
      <Pop delay={at} out={out} from="right" dist={260} preset="bouncy" s={0.9} style={{ position: "absolute", left: 0, top: 0 }}>
        <div style={{ transform: "translateY(30px) scale(0.93)", opacity: 0.5 }}>
          <Glass w={840} h={196} r={36} />
        </div>
      </Pop>
      <Pop delay={at + 3} out={out} from="right" dist={320} preset="bouncy" s={0.9}>
        <Glass w={840} h={196} r={36} strong pad={34}>
          <div style={{ display: "flex", alignItems: "center", gap: 34 }}>
            <div style={{ position: "relative", width: 112, height: 112 }}>
              {[0, 1].map((k) => {
                const q = (((frame - at - 14 - k * 22) % 66) + 66) % 66;
                const on = frame - at - 14 - k * 22 >= 0;
                return (
                  on && (
                    <div
                      key={k}
                      style={{
                        position: "absolute",
                        inset: 0,
                        borderRadius: 36,
                        border: `2px solid ${c.hero}`,
                        opacity: (1 - q / 66) * 0.7,
                        transform: `scale(${1 + (q / 66) * 0.7})`,
                      }}
                    />
                  )
                );
              })}
              <div
                style={{
                  width: 112,
                  height: 112,
                  borderRadius: 36,
                  background: c.hero,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  transform: `rotate(${Math.sin(frame / 3) * (frame < at + 40 ? 10 : 0)}deg)`,
                }}
              >
                <Icon name="bell" size={56} color={c.onHero} />
              </div>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 18, flex: 1 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
                <div style={{ fontFamily: theme.fonts.main, fontWeight: theme.weight.strong, fontSize: 40, color: c.fg, lineHeight: 1.3 }}>
                  New message
                </div>
                <Chip text="client" icon="user" size={24} />
              </div>
              <Skel widths={[520, 340]} h={15} delay={at + 12} />
            </div>
          </div>
        </Glass>
      </Pop>
    </div>
  );
};

export const S01Hook: React.FC = () => {
  const T = T1;
  const t2 = T.t(2);
  const t3 = T.t(3);
  return (
    <SceneShell tone="dark" bg="night" fadeIn={false}>
      <AbsoluteFill>
        <Moon t3={t3} />
        <Zs t3={t3} />
        <Clock t2={t2} />

        {/* ফেজ ১: রাত তিনটা */}
        <div style={{ position: "absolute", left: 0, right: 0, top: 118, display: "flex", justifyContent: "center" }}>
          <Words text="গতকাল রাত ঠিক" size={64} delay={4} per={4} align="center" dim={[0, 1]} hero={[2]} out={t2 - 2} />
        </div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 770, display: "flex", justifyContent: "center" }}>
          <Words text="তিনটার দিকে" size={64} delay={20} per={4} align="center" dim={[1, 2]} hero={[0]} out={t2 - 2} />
        </div>

        {/* ফেজ ২: client message */}
        <div style={{ position: "absolute", left: 0, right: 0, top: 330, display: "flex", justifyContent: "center" }}>
          <Words text="client আমাকে message দেয়" size={88} delay={t2 + 2} per={4} align="center" dim={[1]} hero={[0]} grad={[2]} out={t3 - 4} />
        </div>
        <Notification at={t2} out={t3 - 6} />

        {/* ফেজ ৩: ঘুমাচ্ছি */}
        <div style={{ position: "absolute", left: 150, top: 330 }}>
          <Words text="আমি তো তখন নাক ডেকে ঘুমাচ্ছি" size={108} delay={t3 + 2} per={4} maxWidth={860} dim={[0, 1, 2]} grad={[5]} />
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
