import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { SceneShell } from "../components/SceneShell";
import { CL, Pop, Words, ramp, useSp } from "../components/Motion";
import { Icon } from "../components/Icons";
import { Chip } from "../components/Ui";
import { useC } from "../components/Tone";
import { SfxEvent } from "../components/Sfx";
import { Timer, makeTimer } from "../timing";
import { theme } from "../theme";

export const T6A = makeTimer(14, 16);
export const sfx6a = (T: Timer): SfxEvent[] => [
  { at: T.from + 22, name: "pop" },
  { at: T.from + 34, name: "pop", rate: 1.06, vol: 0.85 },
  { at: T.from + T.t(15) + 40, name: "click", vol: 0.8 },
];

const XS = [520, 960, 1400];

const Folder: React.FC<{ i: number; delay: number; dim: number }> = ({ i, delay, dim }) => {
  const frame = useCurrentFrame();
  const c = useC();
  const p = useSp(delay, "bouncy");
  const y = interpolate(p, [0, 1], [-260, 0]) + Math.sin((frame + i * 20) / 38) * 5;
  return (
    <div
      style={{
        position: "absolute",
        left: XS[i] - 130,
        top: 300,
        width: 260,
        opacity: Math.min(1, p * 1.6) * (1 - dim * 0.45),
        transform: `translateY(${y}px) scale(${1 - dim * 0.1})`,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 20,
      }}
    >
      <Icon name="folder" size={210} color={c.hero} stroke={1.15} fill={`${theme.alpha.white(0.07)}`} />
      <Chip text="client" icon="user" size={26} />
    </div>
  );
};

export const S06aFolders: React.FC = () => {
  const T = T6A;
  const t15 = T.t(15);
  const frame = useCurrentFrame();
  const c = useC();
  const dim = ramp(frame, t15, t15 + 14);
  const boxP = useSp(t15 + 2, "smooth");
  const BX = 960, BY = 790;
  return (
    <SceneShell tone="dark" bg="grid">
      <AbsoluteFill>
        <div style={{ position: "absolute", left: 0, right: 0, top: 64, display: "flex", justifyContent: "center" }}>
          <Words text="Well, সত্যি বলতে" size={44} delay={1} per={4} align="center" dim={[0, 1, 2]} out={t15 - 2} />
        </div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 128, display: "flex", justifyContent: "center" }}>
          <Words text="আগে যেসব client এর কাজ করেছি" size={80} delay={5} per={4} align="center" hero={[2]} out={t15 - 2} />
        </div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 112, display: "flex", justifyContent: "center" }}>
          <Words text="file আলাদা করে রাখা হয়নি" size={84} delay={t15 + 2} per={4} align="center" mark={[0]} hero={[3, 4]} />
        </div>

        {[0, 1, 2].map((i) => (
          <Folder key={i} i={i} delay={20 + i * 7} dim={dim} />
        ))}

        {/* "নিজের কাছে" ফাঁকা বাক্স */}
        <div
          style={{
            position: "absolute",
            left: BX - 360,
            top: BY - 110,
            width: 720,
            height: 220,
            borderRadius: 44,
            border: `3px dashed ${c.dim}`,
            opacity: Math.min(1, boxP * 1.5),
            transform: `scale(${0.88 + 0.12 * boxP})`,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 22,
          }}
        >
          <Icon name="folder" size={72} color={c.dim} stroke={1.3} />
          <div style={{ fontFamily: theme.fonts.main, fontWeight: theme.weight.strong, fontSize: 44, color: c.dim, lineHeight: 1.3 }}>নিজের কাছে</div>
        </div>

        {/* ফাইল উড়ে যায় ও বাতিল হয় */}
        {[0, 1, 2].map((i) => {
          const st = t15 + 14 + i * 12;
          const q = ramp(frame, st, st + 24, theme.ease.inOut);
          const sx = XS[i];
          const sy = 470;
          const tx = BX + (i - 1) * 170;
          const ty = BY;
          const x = interpolate(q, [0, 1], [sx, tx]);
          const y = interpolate(q, [0, 1], [sy, ty]) - Math.sin(q * Math.PI) * 60;
          const rej = ramp(frame, st + 24, st + 36);
          if (frame < st) return null;
          return (
            <React.Fragment key={i}>
              <div style={{ position: "absolute", left: x - 44, top: y - 54, opacity: (1 - rej) * 0.95, transform: `rotate(${(1 - q) * -10}deg) scale(${1 - rej * 0.3})` }}>
                <Icon name="file" size={88} color={c.hero} stroke={1.4} fill={`${theme.alpha.white(0.08)}`} />
              </div>
              <div style={{ position: "absolute", left: tx - 38, top: ty - 38, opacity: rej, transform: `scale(${0.3 + 0.7 * rej})` }}>
                <div style={{ width: 76, height: 76, borderRadius: 76, background: c.hero, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <Icon name="x" size={40} color={c.onHero} stroke={2.8} />
                </div>
              </div>
            </React.Fragment>
          );
        })}
      </AbsoluteFill>
    </SceneShell>
  );
};
