// theme.ts — প্রজেক্টের একমাত্র সত্য-উৎস: রং, ইজিং, spring, ফন্ট।
// স্কিম: Midnight Mono (ইউজারের নির্বাচিত)। কম্পোনেন্টে সরাসরি রঙের কোড নয়।
import { Easing } from "remotion";

export const theme = {
  colors: {
    bg: "#07080B", // ব্যাকগ্রাউন্ড
    hero: "#FFFFFF", // হিরো
    accent: "#8A93A6", // অ্যাকসেন্ট
    text: "#F2F4F8", // টেক্সট
    // একই স্কিমের নিউট্রাল শেড (গভীরতা/প্যানেলের জন্য)
    bgAlt: "#0C0F15",
    panel: "#131822",
    panelHi: "#1B2231",
    line: "rgba(242,244,248,0.12)",
    lineStrong: "rgba(242,244,248,0.24)",
    glow: "rgba(255,255,255,0.38)",
    shadow: "rgba(0,0,0,0.65)",
  },
  // হালকা সিনের জন্য স্কিম উল্টে নেওয়া (টেক্সট রং = ব্যাকগ্রাউন্ড, ব্যাকগ্রাউন্ড রং = কালি)
  light: {
    bg: "#F2F4F8",
    bgAlt: "#E7EBF3",
    blob: "#D6DDEA",
    ink: "#07080B",
    fg: "#12151C",
    dim: "#5B6476",
    panel: "#FFFFFF",
    line: "rgba(7,8,11,0.10)",
    lineStrong: "rgba(7,8,11,0.22)",
    shadow: "rgba(24,32,56,0.28)",
  },
  // স্কিমের রং থেকে স্বচ্ছতা-ভেরিয়েন্ট (সব alpha এখান দিয়ে)
  alpha: {
    white: (a: number) => `rgba(255,255,255,${a})`,
    text: (a: number) => `rgba(242,244,248,${a})`,
    ink: (a: number) => `rgba(7,8,11,${a})`,
    accent: (a: number) => `rgba(138,147,166,${a})`,
    black: (a: number) => `rgba(0,0,0,${a})`,
  },
  // ফোন মকআপের নিউট্রাল শেড
  device: {
    bodyFrom: "#2C3240",
    bodyMid: "#12151C",
    bodyTo: "#0A0B0F",
    button: "#222733",
    screen: "#000000",
  },
  fonts: {
    // Latin → Poppins, বাংলা → Hind Siliguri (দুটোই public/fonts-এ, অফলাইনে চলে)
    main: '"Ridwan Sans", "Hind Siliguri", "Poppins", sans-serif',
  },
  weight: { body: 500, strong: 600, heavy: 700 },
  radius: { sm: 14, md: 26, lg: 40 },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
    soft: Easing.bezier(0.33, 1, 0.68, 1),
  },
  spring: {
    snappy: { damping: 14, stiffness: 170, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
    slow: { damping: 26, stiffness: 55, mass: 1.1 },
  },
  motion: {
    enter: 20, // প্রবেশের মোটামুটি ফ্রেম
    exit: 10, // প্রস্থান — প্রবেশের চেয়ে দ্রুত
    overlap: 12, // দুই সিনের ওভারল্যাপ (ট্রানজিশনের সময়)
  },
} as const;

export type SpringName = keyof typeof theme.spring;
