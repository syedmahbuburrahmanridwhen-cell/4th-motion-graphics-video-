import type React from "react";
import { Timer } from "./timing";
import type { SfxEvent } from "./components/Sfx";
import { S01Hook, sfx1 } from "./scenes/S01Hook";
import { S02Ai, sfx2 } from "./scenes/S02Ai";
import { S03Morning, sfx3 } from "./scenes/S03Morning";
import { S04Gauge, sfx4 } from "./scenes/S04Gauge";
import { S05Question, sfx5 } from "./scenes/S05Question";
import { S06aFolders, sfx6a } from "./scenes/S06aFolders";
import { S06bProcess, sfx6b } from "./scenes/S06bProcess";
import { S07Carousel, sfx7 } from "./scenes/S07Carousel";
import { S08Charge, sfx8 } from "./scenes/S08Charge";
import { S09aInbox, sfx9a } from "./scenes/S09aInbox";
import { S09bPremium, sfx9b } from "./scenes/S09bPremium";
import { S09cCta, sfx9c } from "./scenes/S09cCta";

export type SceneDef = {
  id: string;
  first: number;
  next?: number;
  Comp: React.FC;
  sfx: (T: Timer) => SfxEvent[];
};

// সিনের সীমা পুরোপুরি SRT cue-র সীমায় মেলে (প্রতি সিনের প্রথম cue নম্বর)
export const SCENES: SceneDef[] = [
  { id: "S01-hook", first: 1, next: 4, Comp: S01Hook, sfx: sfx1 },
  { id: "S02-ai", first: 4, next: 6, Comp: S02Ai, sfx: sfx2 },
  { id: "S03-morning", first: 6, next: 8, Comp: S03Morning, sfx: sfx3 },
  { id: "S04-gauge", first: 8, next: 11, Comp: S04Gauge, sfx: sfx4 },
  { id: "S05-question", first: 11, next: 14, Comp: S05Question, sfx: sfx5 },
  { id: "S06a-folders", first: 14, next: 16, Comp: S06aFolders, sfx: sfx6a },
  { id: "S06b-process", first: 16, next: 18, Comp: S06bProcess, sfx: sfx6b },
  { id: "S07-carousel", first: 18, next: 21, Comp: S07Carousel, sfx: sfx7 },
  { id: "S08-charge", first: 21, next: 24, Comp: S08Charge, sfx: sfx8 },
  { id: "S09a-inbox", first: 24, next: 28, Comp: S09aInbox, sfx: sfx9a },
  { id: "S09b-premium", first: 28, next: 30, Comp: S09bPremium, sfx: sfx9b },
  { id: "S09c-cta", first: 30, Comp: S09cCta, sfx: sfx9c },
];

export { WEBSITE_FRAMES, WEBSITE_START, PHONE_IN, PHONE_MOVE } from "./phoneTiming";
