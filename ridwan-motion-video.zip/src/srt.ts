import { SRT_RAW } from "./srtData";

export const FPS = 30;
/** ভিজ্যুয়াল সংশ্লিষ্ট কথার এতটুকু ফ্রেম আগে ঢোকে */
export const LEAD = 5;

export type Cue = { n: number; start: number; end: number; text: string };

const toSec = (t: string) => {
  const m = t.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  if (!m) return 0;
  return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4] / 1000;
};

export const CUES: Cue[] = SRT_RAW.split(/\n\s*\n/)
  .map((block) => block.trim().split("\n"))
  .filter((l) => l.length >= 3)
  .map((l) => {
    const [a, b] = l[1].split("-->");
    return { n: parseInt(l[0], 10), start: toSec(a), end: toSec(b), text: l.slice(2).join(" ") };
  });

const byN = (n: number) => {
  const c = CUES.find((x) => x.n === n);
  if (!c) throw new Error(`SRT-এ cue ${n} নেই`);
  return c;
};

/** cue শুরুর ফ্রেম (পরম) */
export const cueStart = (n: number) => Math.round(byN(n).start * FPS);
/** cue শেষের ফ্রেম (পরম) */
export const cueEnd = (n: number) => Math.round(byN(n).end * FPS);
/** cue-র ভেতরে অনুপাত (০–১) ধরে ফ্রেম — শব্দের অবস্থান অক্ষর-অনুপাতে অনুমান */
export const cueAt = (n: number, frac: number) => {
  const c = byN(n);
  return Math.round((c.start + (c.end - c.start) * frac) * FPS);
};

/** পুরো ভিডিওর দৈর্ঘ্য: শেষ cue-র শেষ পর্যন্ত */
export const TOTAL_FRAMES = Math.ceil(Math.max(...CUES.map((c) => c.end)) * FPS);

export type SceneDef = {
  id: string;
  firstCue: number;
  nextCue?: number; // পরের সিনের প্রথম cue; না থাকলে ভিডিওর শেষ
};

/** সিনের শুরু ফ্রেম = প্রথম cue-র শুরু − LEAD */
export const sceneFrom = (firstCue: number) => (firstCue === 1 ? 0 : cueStart(firstCue) - LEAD);
