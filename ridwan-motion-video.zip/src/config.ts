// config.ts — ভিডিওর সাধারণ সেটিং ও ফ্ল্যাগ
export const VIDEO = {
  width: 1920,
  height: 1080,
  fps: 30,
};

/** ভয়েসওভার প্রিভিউ ফ্ল্যাগ: public/voiceover.mp3 থাকলে Studio-তে বাজবে */
export const VOICEOVER_IN_STUDIO = true;
/** রেন্ডারে ভয়েসওভার মেশাতে চাইলে true করুন (ডিফল্টে বন্ধ) */
export const VOICEOVER_IN_RENDER = false;
/** SFX চালু/বন্ধ */
export const SFX_ENABLED = true;

/** ওয়েবসাইট স্ক্রিন-রেকর্ডিংয়ের আসল দৈর্ঘ্য (ffprobe: 20.039s) ও আকার (992×1920) */
export const WEBSITE_VIDEO = {
  file: "website.mp4",
  seconds: 20.039,
  width: 992,
  height: 1920,
};
