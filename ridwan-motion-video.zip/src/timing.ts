import { LEAD, cueAt, cueStart, sceneFrom, TOTAL_FRAMES } from "./srt";
import { theme } from "./theme";

/**
 * সিন-লোকাল টাইমার: সব সময় SRT থেকে।
 * t(n)        = cue n-এর ভিজ্যুয়াল ঢোকার লোকাল ফ্রেম (কথার LEAD ফ্রেম আগে)
 * t(n, frac)  = cue-র ভেতরে অনুপাত ধরে (শব্দের অবস্থান অক্ষর-অনুপাতে অনুমান)
 */
export const makeTimer = (firstCue: number, nextCue?: number) => {
  const from = sceneFrom(firstCue);
  const to = nextCue ? sceneFrom(nextCue) : TOTAL_FRAMES;
  const dur = to - from + (nextCue ? theme.motion.overlap : 0);
  const t = (n: number, frac = 0) => {
    const abs = frac === 0 ? cueStart(n) : cueAt(n, frac);
    return Math.max(0, abs - LEAD - from);
  };
  return { from, to, dur, t, abs: (local: number) => from + local, exitAt: dur - theme.motion.overlap };
};
export type Timer = ReturnType<typeof makeTimer>;
