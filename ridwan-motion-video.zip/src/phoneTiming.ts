import { FPS, TOTAL_FRAMES, sceneFrom } from "./srt";
import { WEBSITE_VIDEO } from "./config";

export const WEBSITE_FRAMES = Math.round(WEBSITE_VIDEO.seconds * FPS);
/** রেকর্ডিং এমনভাবে বসে যেন পুরোটা একবারে চলে ঠিক ভিডিওর শেষে থামে */
export const WEBSITE_START = TOTAL_FRAMES - WEBSITE_FRAMES;
export const PHONE_IN = WEBSITE_START - 18;
/** শেষ সিন (cue 30) শুরুতে ফোন ডান থেকে বামে সরে */
export const PHONE_MOVE = sceneFrom(30);
