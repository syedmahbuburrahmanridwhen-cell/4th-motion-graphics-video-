import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { theme } from "./theme";
import { FontLoader } from "./components/Fonts";
import { PreviewAudio } from "./components/PreviewAudio";
import { Grain } from "./components/Overlays";
import { Transitions } from "./components/Transitions";
import { SfxEvent, SfxLayer } from "./components/Sfx";
import { Phone } from "./components/Phone";
import { makeTimer } from "./timing";
import { SCENES } from "./plan";
import { PHONE_IN, PHONE_MOVE, WEBSITE_FRAMES, WEBSITE_START } from "./phoneTiming";

const TIMERS = SCENES.map((s) => makeTimer(s.first, s.next));
const BOUNDARIES = TIMERS.slice(0, -1).map((t) => t.to);

const EVENTS: SfxEvent[] = [
  ...SCENES.flatMap((s, i) => s.sfx(TIMERS[i])),
  // সিন ট্রানজিশনে ছোট whoosh (পিচ সামান্য বদলে)
  ...BOUNDARIES.map((b, i) => ({ at: b - 3, name: "whoosh" as const, rate: 0.96 + (i % 3) * 0.05, vol: 0.85 })),
];

export const Main: React.FC = () => {
  return (
    <AbsoluteFill style={{ background: theme.colors.bg, fontFamily: theme.fonts.main }}>
      <FontLoader />
      <PreviewAudio />
      {SCENES.map((s, i) => (
        <Sequence key={s.id} from={TIMERS[i].from} durationInFrames={TIMERS[i].dur} name={s.id}>
          <s.Comp />
        </Sequence>
      ))}
      <Phone inAt={PHONE_IN} moveAt={PHONE_MOVE} videoStart={WEBSITE_START} videoFrames={WEBSITE_FRAMES} />
      <Transitions at={BOUNDARIES} />
      <Grain />
      <SfxLayer events={EVENTS} />
    </AbsoluteFill>
  );
};
