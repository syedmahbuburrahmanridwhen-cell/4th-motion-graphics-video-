import React from "react";
import { AbsoluteFill, OffthreadVideo, Sequence, interpolate, staticFile, useCurrentFrame } from "remotion";
import { WEBSITE_VIDEO, VIDEO } from "../config";
import { theme } from "../theme";
import { useBreathe, useFloat, useSp } from "./Motion";

const SCREEN_W = 480;
const SCREEN_H = Math.round((SCREEN_W * WEBSITE_VIDEO.height) / WEBSITE_VIDEO.width); // 929
const BEZEL = 13;

/**
 * ফোন মকআপ — ওয়েবসাইটের স্ক্রিন-রেকর্ডিং পুরোটা একবারে চলে।
 * inAt: ঢোকার ফ্রেম, moveAt: ডানে থেকে বামে সরার ফ্রেম, videoStart: রেকর্ডিং শুরুর ফ্রেম (সব পরম ফ্রেম)।
 */
export const Phone: React.FC<{ inAt: number; moveAt: number; videoStart: number; videoFrames: number }> = ({
  inAt,
  moveAt,
  videoStart,
  videoFrames,
}) => {
  const frame = useCurrentFrame();
  const enter = useSp(inAt, "smooth");
  const move = useSp(moveAt, "smooth");
  const fl = useFloat(7, 150);
  const br = useBreathe(120, 0.006);
  if (frame < inAt - 1) return null;

  const RIGHT_X = 1390;
  const LEFT_X = 520;
  const x = interpolate(enter, [0, 1], [2450, RIGHT_X]) + (LEFT_X - RIGHT_X) * move;
  const rotY = interpolate(enter, [0, 1], [-38, -12]) + 24 * move;
  const rotZ = interpolate(enter, [0, 1], [5, -1.2]) + 2.4 * move;
  const outerW = SCREEN_W + BEZEL * 2;
  const outerH = SCREEN_H + BEZEL * 2;
  const glow = interpolate(enter, [0, 1], [0, 1]);

  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      <div
        style={{
          position: "absolute",
          left: x - 520,
          top: 540 - 520 + fl,
          width: 1040,
          height: 1040,
          borderRadius: "50%",
          background: `radial-gradient(circle, ${theme.alpha.white(0.17 * glow)}, ${theme.alpha.white(0)} 62%)`,
        }}
      />
      <div
        style={{
          position: "absolute",
          left: x - outerW / 2,
          top: 540 - outerH / 2 + fl,
          width: outerW,
          height: outerH,
          transform: `perspective(2400px) rotateY(${rotY}deg) rotateX(2deg) rotateZ(${rotZ}deg) scale(${br})`,
          transformStyle: "preserve-3d",
        }}
      >
        <div
          style={{
            width: "100%",
            height: "100%",
            borderRadius: 68,
            padding: BEZEL,
            boxSizing: "border-box",
            background: `linear-gradient(145deg, ${theme.device.bodyFrom} 0%, ${theme.device.bodyMid} 45%, ${theme.device.bodyTo} 100%)`,
            border: `1.5px solid ${theme.colors.lineStrong}`,
            boxShadow: `0 60px 120px -30px ${theme.colors.shadow}, 0 0 0 1px ${theme.alpha.black(0.6)}, inset 0 1px 0 ${theme.alpha.white(0.22)}`,
          }}
        >
          <div style={{ position: "relative", width: SCREEN_W, height: SCREEN_H, borderRadius: 56, overflow: "hidden", background: theme.device.screen }}>
            <Sequence from={videoStart} durationInFrames={videoFrames} layout="none">
              <OffthreadVideo
                src={staticFile(WEBSITE_VIDEO.file)}
                muted
                style={{ position: "absolute", left: 0, top: 0, width: SCREEN_W, height: SCREEN_H, objectFit: "cover" }}
              />
            </Sequence>
            <AbsoluteFill
              style={{
                background: `linear-gradient(115deg, ${theme.alpha.white(0.10)} 0%, ${theme.alpha.white(0.0)} 34%, ${theme.alpha.white(0)} 100%)`,
              }}
            />
          </div>
        </div>
        {/* সাইড বাটন */}
        <div style={{ position: "absolute", right: -5, top: 230, width: 5, height: 110, borderRadius: 3, background: theme.device.button }} />
        <div style={{ position: "absolute", left: -5, top: 190, width: 5, height: 70, borderRadius: 3, background: theme.device.button }} />
      </div>
    </AbsoluteFill>
  );
};

export const PHONE_SIZE = { w: SCREEN_W + BEZEL * 2, h: SCREEN_H + BEZEL * 2, fps: VIDEO.fps };
