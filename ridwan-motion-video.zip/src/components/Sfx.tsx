import React from "react";
import { Audio, Sequence, staticFile } from "remotion";
import { SFX_ENABLED } from "../config";

export type SfxName = "whoosh" | "pop" | "click" | "pluck" | "chime" | "thud";
export type SfxEvent = { at: number; name: SfxName; vol?: number; rate?: number };

// সাউন্ডের স্বাভাবিক দৈর্ঘ্য (ফ্রেমে, ৩০fps-এ) — Sequence-এর সীমা
const LEN: Record<SfxName, number> = { whoosh: 28, pop: 12, click: 8, pluck: 20, chime: 22, thud: 16 };
// ভিডিওতে ভলিউম — সংযত (০.২–০.৩৫)
const BASE: Record<SfxName, number> = { whoosh: 0.3, pop: 0.32, click: 0.28, pluck: 0.3, chime: 0.26, thud: 0.34 };

export const SfxLayer: React.FC<{ events: SfxEvent[] }> = ({ events }) => {
  if (!SFX_ENABLED) return null;
  return (
    <>
      {events.map((e, i) => (
        <Sequence key={i} from={Math.max(0, Math.round(e.at))} durationInFrames={LEN[e.name] + 4} layout="none">
          <Audio
            src={staticFile(`sfx/${e.name}.wav`)}
            volume={Math.min(0.35, (e.vol ?? 1) * BASE[e.name])}
            playbackRate={e.rate ?? 1}
          />
        </Sequence>
      ))}
    </>
  );
};
