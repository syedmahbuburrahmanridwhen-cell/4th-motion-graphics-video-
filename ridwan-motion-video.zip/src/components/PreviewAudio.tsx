import React, { useEffect, useState } from "react";
import { Audio, continueRender, delayRender, getRemotionEnvironment, staticFile } from "remotion";
import { VOICEOVER_IN_RENDER, VOICEOVER_IN_STUDIO } from "../config";

/**
 * public/voiceover.mp3 থাকলে বাজবে, না থাকলে নীরবে বাদ।
 * Studio প্রিভিউয়ে ডিফল্টে চালু; রেন্ডারে ডিফল্টে বন্ধ (config.ts-এর ফ্ল্যাগ)।
 */
export const PreviewAudio: React.FC = () => {
  const { isRendering } = getRemotionEnvironment();
  const enabled = isRendering ? VOICEOVER_IN_RENDER : VOICEOVER_IN_STUDIO;
  const [exists, setExists] = useState(false);
  const [handle] = useState(() => (enabled ? delayRender("voiceover-check") : null));

  useEffect(() => {
    if (!enabled || handle === null) return;
    let alive = true;
    fetch(staticFile("voiceover.mp3"), { method: "HEAD" })
      .then((r) => {
        const type = r.headers.get("content-type") || "";
        if (alive) setExists(r.ok && !type.includes("text/html"));
      })
      .catch(() => undefined)
      .finally(() => continueRender(handle));
    return () => {
      alive = false;
    };
  }, [enabled, handle]);

  if (!enabled || !exists) return null;
  return <Audio src={staticFile("voiceover.mp3")} />;
};
