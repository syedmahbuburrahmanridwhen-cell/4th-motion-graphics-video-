import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { CL } from "./Motion";

/** সিনের সীমায় ছোট, মসৃণ ট্রানজিশন: ব্যান্ড-সুইপ / রিং / বার-উইপ (difference ব্লেন্ড — হালকা ও গাঢ় দুই ব্যাকগ্রাউন্ডেই দেখা যায়) */
export const Transitions: React.FC<{ at: number[] }> = ({ at }) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{ pointerEvents: "none", mixBlendMode: "difference" }}>
      {at.map((b, i) => {
        if (frame < b - 4 || frame > b + 22) return null;
        const kind = i % 3;
        if (kind === 0) {
          const p = interpolate(frame, [b - 3, b + 17], [0, 1], { ...CL, easing: theme.ease.inOut });
          return (
            <div
              key={i}
              style={{
                position: "absolute",
                top: -250,
                left: -700 + p * 3300,
                width: 520,
                height: 1700,
                transform: "rotate(14deg)",
                filter: "blur(10px)",
                background: `linear-gradient(90deg, ${theme.alpha.white(0)}, ${theme.alpha.white(0.55)}, ${theme.alpha.white(0)})`,
              }}
            />
          );
        }
        if (kind === 1) {
          return (
            <React.Fragment key={i}>
              {[0, 4].map((d) => {
                const p = interpolate(frame, [b - 3 + d, b + 17 + d], [0, 1], { ...CL, easing: theme.ease.out });
                return (
                  <div
                    key={d}
                    style={{
                      position: "absolute",
                      left: 960 - 300,
                      top: 540 - 300,
                      width: 600,
                      height: 600,
                      borderRadius: "50%",
                      border: `${d ? 2 : 4}px solid ${theme.alpha.white(0.8)}`,
                      transform: `scale(${0.1 + p * 4.6})`,
                      opacity: (1 - p) * 0.9,
                    }}
                  />
                );
              })}
            </React.Fragment>
          );
        }
        return (
          <React.Fragment key={i}>
            {Array.from({ length: 6 }).map((_, k) => {
              const q = interpolate(frame, [b - 3 + k * 1.5, b + 15 + k * 1.5], [0, 1], { ...CL, easing: theme.ease.inOut });
              const grow = q < 0.5 ? q * 2 : (1 - q) * 2;
              return (
                <div
                  key={k}
                  style={{
                    position: "absolute",
                    left: 0,
                    top: k * 180,
                    width: 1920,
                    height: 180,
                    background: `${theme.alpha.white(0.34)}`,
                    transformOrigin: q < 0.5 ? "0% 50%" : "100% 50%",
                    transform: `scaleX(${grow})`,
                  }}
                />
              );
            })}
          </React.Fragment>
        );
      })}
    </AbsoluteFill>
  );
};
