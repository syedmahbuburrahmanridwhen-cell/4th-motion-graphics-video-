import React, { useEffect, useState } from "react";
import { cancelRender, continueRender, delayRender, staticFile } from "remotion";

// অফলাইনে চলে: ফন্ট ফাইল public/fonts-এ। Latin → Poppins, বাংলা → Hind Siliguri।
const LATIN = "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD";
const BENGALI = "U+0951-0952,U+0964-0965,U+0980-09FE,U+1CD0,U+200C-200D,U+20B9,U+25CC,U+A8F1";

const FACES = [500, 600, 700].flatMap((w) => [
  { file: `fonts/poppins-latin-${w}-normal.woff2`, weight: w, range: LATIN },
  { file: `fonts/hind-siliguri-bengali-${w}-normal.woff2`, weight: w, range: BENGALI },
]);

export const FontLoader: React.FC = () => {
  const [handle] = useState(() => delayRender("fonts"));
  useEffect(() => {
    Promise.all(
      FACES.map(async (f) => {
        const face = new FontFace("Ridwan Sans", `url(${staticFile(f.file)})`, {
          weight: String(f.weight),
          unicodeRange: f.range,
        });
        await face.load();
        (document.fonts as unknown as { add: (f: FontFace) => void }).add(face);
      })
    )
      .then(() => continueRender(handle))
      .catch((e) => cancelRender(e));
  }, [handle]);
  return null;
};
