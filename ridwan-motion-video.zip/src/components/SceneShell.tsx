import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { Background, BgVariant } from "./Backgrounds";
import { Grade, Vignette } from "./Overlays";
import { Tone, ToneProvider } from "./Tone";
import { CL } from "./Motion";

/**
 * পাঁচ-স্তরের স্ট্যাক: ব্যাকগ্রাউন্ড → অ্যাসেট/গ্রাফিক্স → গ্রেড → ভিনিয়েট (+ গ্লোবাল গ্রেইন)।
 * সিনের শুরুতে ব্যাকগ্রাউন্ড আগের সিনের উপর ক্রস-ফেড হয়; শেষে কনটেন্ট দ্রুত বেরিয়ে যায়।
 */
export const SceneShell: React.FC<{
  tone: Tone;
  bg: BgVariant;
  globe?: { cx: number; cy: number; R: number; op?: number };
  fadeIn?: boolean;
  exit?: boolean;
  children: React.ReactNode;
}> = ({ tone, bg, globe, fadeIn = true, exit = true, children }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const ov = theme.motion.overlap;
  const bgOp = fadeIn ? interpolate(frame, [0, ov + 2], [0, 1], { ...CL, easing: theme.ease.out }) : 1;
  const ex = exit ? interpolate(frame, [durationInFrames - ov, durationInFrames - 2], [0, 1], { ...CL, easing: theme.ease.in }) : 0;
  return (
    <ToneProvider tone={tone}>
      <AbsoluteFill style={{ opacity: bgOp }}>
        <Background variant={bg} globe={globe} />
      </AbsoluteFill>
      <AbsoluteFill
        style={{
          opacity: 1 - ex,
          transform: `translateY(${-ex * 34}px) scale(${1 + ex * 0.035})`,
          filter: ex > 0.05 ? `blur(${ex * 7}px)` : undefined,
        }}
      >
        {children}
      </AbsoluteFill>
      <Grade tone={tone} />
      <Vignette tone={tone} />
    </ToneProvider>
  );
};
