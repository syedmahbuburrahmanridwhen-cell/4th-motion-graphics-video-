import React from "react";
import { AbsoluteFill, staticFile, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import type { Tone } from "./Tone";

/** কালার গ্রেড — সব লেয়ারকে এক লুকে বাঁধে */
export const Grade: React.FC<{ tone: Tone }> = ({ tone }) => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.accent, mixBlendMode: "soft-light", opacity: tone === "dark" ? 0.16 : 0.08 }} />
    <AbsoluteFill
      style={{
        background:
          tone === "dark"
            ? `linear-gradient(180deg, ${theme.alpha.black(0.10)}, transparent 28%, transparent 72%, ${theme.alpha.black(0.18)})`
            : `linear-gradient(180deg, ${theme.alpha.ink(0.03)}, transparent 28%, transparent 72%, ${theme.alpha.ink(0.06)})`,
      }}
    />
  </AbsoluteFill>
);

export const Vignette: React.FC<{ tone: Tone }> = ({ tone }) => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background: `radial-gradient(ellipse at center, transparent 55%, ${tone === "dark" ? `${theme.alpha.black(0.40)}` : `${theme.alpha.ink(0.10)}`} 100%)`,
    }}
  />
);

/** ফিল্ম গ্রেইন — public/grain.png টাইল, প্রতি ফ্রেমে সরে (ফ্লিকার) */
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        backgroundImage: `url(${staticFile("grain.png")})`,
        backgroundSize: "256px 256px",
        backgroundPosition: `${(frame * 37) % 256}px ${(frame * 91) % 256}px`,
        mixBlendMode: "overlay",
        opacity: 0.16,
      }}
    />
  );
};
