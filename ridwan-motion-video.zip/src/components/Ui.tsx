import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { useC } from "./Tone";
import { CL, ramp } from "./Motion";
import { Icon } from "./Icons";

/** গ্লাস/UI কার্ড — একই কোণ, ছায়া, বর্ডার সারা ভিডিওতে */
export const Glass: React.FC<{
  w?: number | string;
  h?: number | string;
  r?: number;
  pad?: number;
  strong?: boolean;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({ w, h, r = theme.radius.md, pad = 0, strong, style, children }) => {
  const c = useC();
  const dark = c.tone === "dark";
  return (
    <div
      style={{
        width: w,
        height: h,
        borderRadius: r,
        padding: pad,
        boxSizing: "border-box",
        position: "relative",
        background: dark
          ? `linear-gradient(160deg, ${theme.alpha.white(strong ? 0.13 : 0.085)}, ${theme.alpha.white(0.025)})`
          : c.surface,
        border: `1px solid ${strong ? c.lineStrong : c.line}`,
        boxShadow: dark
          ? `0 36px 70px -26px ${c.shadow}, inset 0 1px 0 ${theme.alpha.white(0.14)}`
          : `0 36px 70px -30px ${c.shadow}, inset 0 1px 0 ${theme.alpha.white(0.9)}`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/** স্কেলিটন লাইন — আসল টেক্সট বানানোর বদলে নিরপেক্ষ UI */
export const Skel: React.FC<{
  widths: number[];
  h?: number;
  gap?: number;
  delay?: number;
  hero?: boolean;
  align?: "left" | "right";
}> = ({ widths, h = 14, gap = 12, delay = 0, hero, align = "left" }) => {
  const frame = useCurrentFrame();
  const c = useC();
  const dark = c.tone === "dark";
  return (
    <div style={{ display: "flex", flexDirection: "column", gap, alignItems: align === "left" ? "flex-start" : "flex-end" }}>
      {widths.map((w, i) => {
        const p = ramp(frame, delay + i * 4, delay + i * 4 + 14);
        const sweep = interpolate((frame + i * 14) % 90, [0, 90], [-40, 140], CL);
        const base = hero
          ? dark
            ? `${theme.alpha.ink(0.18)}`
            : `${theme.alpha.text(0.28)}`
          : dark
          ? `${theme.alpha.text(0.16)}`
          : `${theme.alpha.ink(0.12)}`;
        const shine = hero ? `${theme.alpha.ink(0.12)}` : dark ? `${theme.alpha.white(0.28)}` : `${theme.alpha.white(0.85)}`;
        return (
          <div
            key={i}
            style={{
              width: w * p,
              height: h,
              borderRadius: h,
              background: `linear-gradient(100deg, ${base} ${sweep - 25}%, ${shine} ${sweep}%, ${base} ${sweep + 25}%)`,
              opacity: p,
            }}
          />
        );
      })}
    </div>
  );
};

export const Avatar: React.FC<{ size?: number; icon?: string; solid?: boolean; ring?: boolean }> = ({
  size = 84,
  icon = "user",
  solid,
  ring,
}) => {
  const c = useC();
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: size,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: solid ? c.hero : c.surfaceHi,
        border: `1.5px solid ${ring ? c.hero : c.lineStrong}`,
        boxSizing: "border-box",
        flexShrink: 0,
      }}
    >
      <Icon name={icon} size={size * 0.5} color={solid ? c.onHero : c.fg} />
    </div>
  );
};

/** ছোট পিল/চিপ */
export const Chip: React.FC<{
  text: string;
  icon?: string;
  size?: number;
  solid?: boolean;
  style?: React.CSSProperties;
}> = ({ text, icon, size = 30, solid, style }) => {
  const c = useC();
  return (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: Math.round(size * 0.36),
        padding: `${Math.round(size * 0.3)}px ${Math.round(size * 0.66)}px`,
        borderRadius: 999,
        background: solid ? c.hero : c.tone === "dark" ? `${theme.alpha.white(0.07)}` : `${theme.alpha.ink(0.06)}`,
        border: `1px solid ${solid ? "transparent" : c.lineStrong}`,
        color: solid ? c.onHero : c.fg,
        fontFamily: theme.fonts.main,
        fontWeight: theme.weight.strong,
        fontSize: size,
        lineHeight: 1.3,
        letterSpacing: 0,
        whiteSpace: "nowrap",
        ...style,
      }}
    >
      {icon && <Icon name={icon} size={size * 1.05} color={solid ? c.onHero : c.fg} />}
      {text}
    </div>
  );
};

/** মাউস কার্সর */
export const Cursor: React.FC<{ size?: number }> = ({ size = 44 }) => {
  const c = useC();
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" style={{ filter: `drop-shadow(0 6px 10px ${c.shadow})` }}>
      <path d="M4 3l16 7-7 2-2 7z" fill={c.hero} stroke={c.onHero} strokeWidth={1.4} strokeLinejoin="round" />
    </svg>
  );
};

/** ক্লিক রিপল */
export const Ripple: React.FC<{ at: number; size?: number }> = ({ at, size = 120 }) => {
  const frame = useCurrentFrame();
  const c = useC();
  const p = ramp(frame, at, at + 18);
  if (frame < at || p >= 1) return null;
  return (
    <div
      style={{
        position: "absolute",
        left: -size / 2,
        top: -size / 2,
        width: size,
        height: size,
        borderRadius: size,
        border: `2px solid ${c.hero}`,
        opacity: (1 - p) * 0.8,
        transform: `scale(${0.2 + p * 1.1})`,
        pointerEvents: "none",
      }}
    />
  );
};

/** সারি-সারি রশ্মি: স্পার্ক মার্ক */
export const Spark: React.FC<{ size: number; delay: number; rays?: number }> = ({ size, delay, rays = 14 }) => {
  const frame = useCurrentFrame();
  const c = useC();
  return (
    <div style={{ position: "relative", width: size, height: size }}>
      {Array.from({ length: rays }).map((_, i) => {
        const p = ramp(frame, delay + i * 1.4, delay + i * 1.4 + 16, theme.ease.out);
        const pulse = 1 + Math.sin((frame + i * 6) / 14) * 0.08;
        const long = i % 2 === 0;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: "50%",
              top: "50%",
              width: size * 0.028,
              height: size * (long ? 0.2 : 0.12) * p * pulse,
              borderRadius: size,
              background: c.hero,
              opacity: 0.85,
              transformOrigin: "50% 0%",
              transform: `translateX(-50%) rotate(${(360 / rays) * i}deg) translateY(${size * 0.34}px)`,
            }}
          />
        );
      })}
    </div>
  );
};
