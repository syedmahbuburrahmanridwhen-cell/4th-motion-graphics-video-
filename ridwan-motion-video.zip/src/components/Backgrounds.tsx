import React, { useMemo } from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";

export type BgVariant = "night" | "grid" | "light" | "mesh" | "spot" | "globe";

const mulberry32 = (a: number) => () => {
  a |= 0;
  a = (a + 0x6d2b79f5) | 0;
  let t = Math.imul(a ^ (a >>> 15), 1 | a);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

const STARS = (() => {
  const r = mulberry32(7);
  return Array.from({ length: 170 }, () => ({
    x: r() * 1920,
    y: r() * 1080,
    r: 0.6 + r() * 1.5,
    a: 0.25 + r() * 0.6,
    ph: r() * 6.28,
    sp: 0.03 + r() * 0.06,
  }));
})();

const Stars: React.FC<{ op?: number }> = ({ op = 1 }) => {
  const frame = useCurrentFrame();
  return (
    <svg width={1920} height={1080} style={{ position: "absolute", inset: 0, opacity: op }}>
      {STARS.map((s, i) => (
        <circle
          key={i}
          cx={s.x}
          cy={(s.y - frame * 0.08 * (0.4 + s.r * 0.3) + 1080) % 1080}
          r={s.r}
          fill={theme.colors.text}
          opacity={s.a * (0.55 + 0.45 * Math.sin(frame * s.sp + s.ph))}
        />
      ))}
    </svg>
  );
};

// ডটেড গ্লোব — ওয়েবসাইটের গ্লোবের সাথে মেলানো
const GLOBE_PTS = (() => {
  const pts: { x: number; y: number; z: number }[] = [];
  const N = 2600;
  const ga = Math.PI * (3 - Math.sqrt(5));
  for (let i = 0; i < N; i++) {
    const y = 1 - (i / (N - 1)) * 2;
    const rad = Math.sqrt(1 - y * y);
    const th = ga * i;
    const x = Math.cos(th) * rad;
    const z = Math.sin(th) * rad;
    const v =
      Math.sin(x * 2.3 + 1.7) * Math.cos(y * 2.9 - 0.4) +
      Math.sin(z * 3.1 + 0.6) * Math.cos(x * 3.7 + 2.1) * 0.9 +
      Math.sin(y * 5.3 + z * 4.1) * 0.35;
    if (v > 0.12) pts.push({ x, y, z });
  }
  return pts;
})();

export const Globe: React.FC<{ cx: number; cy: number; R: number; op?: number; speed?: number }> = ({
  cx,
  cy,
  R,
  op = 1,
  speed = 0.0065,
}) => {
  const frame = useCurrentFrame();
  const th = frame * speed + 0.6;
  const tilt = 0.38;
  const cT = Math.cos(th), sT = Math.sin(th), cX = Math.cos(tilt), sX = Math.sin(tilt);
  const dots = useMemo(() => GLOBE_PTS, []);
  const out: React.ReactNode[] = [];
  dots.forEach((p, i) => {
    const x1 = p.x * cT + p.z * sT;
    const z1 = -p.x * sT + p.z * cT;
    const y2 = p.y * cX - z1 * sX;
    const z2 = p.y * sX + z1 * cX;
    if (z2 < -0.02) return;
    out.push(
      <circle
        key={i}
        cx={cx + R * x1}
        cy={cy - R * y2}
        r={1.2 + 1.7 * z2}
        fill={theme.colors.hero}
        opacity={(0.18 + 0.82 * z2) * op}
      />
    );
  });
  return (
    <>
      <div
        style={{
          position: "absolute",
          left: cx - R * 1.35,
          top: cy - R * 1.35,
          width: R * 2.7,
          height: R * 2.7,
          borderRadius: "50%",
          background: `radial-gradient(circle, ${theme.alpha.white(0.0)} 54%, ${theme.alpha.white(0.2 * op)} 61%, ${theme.alpha.white(0)} 72%)`,
        }}
      />
      <div
        style={{
          position: "absolute",
          left: cx - R,
          top: cy - R,
          width: R * 2,
          height: R * 2,
          borderRadius: "50%",
          background: `radial-gradient(circle at 36% 30%, ${theme.alpha.white(0.07 * op)}, ${theme.alpha.white(0)} 60%)`,
          border: `1px solid ${theme.alpha.white(0.16 * op)}`,
          boxSizing: "border-box",
        }}
      />
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        {out}
      </svg>
    </>
  );
};

const Blob: React.FC<{ x: number; y: number; s: number; color: string; blur?: number }> = ({ x, y, s, color, blur = 70 }) => (
  <div
    style={{
      position: "absolute",
      left: x - s / 2,
      top: y - s / 2,
      width: s,
      height: s,
      borderRadius: "50%",
      background: `radial-gradient(circle, ${color}, transparent 64%)`,
      filter: `blur(${blur}px)`,
    }}
  />
);

export const Background: React.FC<{
  variant: BgVariant;
  globe?: { cx: number; cy: number; R: number; op?: number };
}> = ({ variant, globe }) => {
  const frame = useCurrentFrame();
  const s1 = Math.sin(frame / 55), c1 = Math.cos(frame / 70), s2 = Math.sin(frame / 90 + 2);

  if (variant === "night")
    return (
      <AbsoluteFill style={{ background: theme.colors.bg }}>
        <Blob x={1500 + s1 * 60} y={230 + c1 * 30} s={1100} color={`${theme.alpha.white(0.11)}`} />
        <Blob x={380 - s2 * 50} y={930} s={1000} color={`${theme.alpha.accent(0.16)}`} />
        <Stars />
      </AbsoluteFill>
    );

  if (variant === "grid")
    return (
      <AbsoluteFill style={{ background: theme.colors.bgAlt }}>
        <Blob x={960 + s1 * 90} y={470} s={1300} color={`${theme.alpha.accent(0.20)}`} blur={90} />
        <AbsoluteFill
          style={{
            backgroundImage: `linear-gradient(${theme.colors.line} 1px, transparent 1px), linear-gradient(90deg, ${theme.colors.line} 1px, transparent 1px)`,
            backgroundSize: "96px 96px",
            backgroundPosition: `${frame * 0.5}px ${frame * 0.35}px`,
            WebkitMaskImage: "radial-gradient(ellipse at 50% 48%, black 14%, transparent 74%)",
            maskImage: "radial-gradient(ellipse at 50% 48%, black 14%, transparent 74%)",
            opacity: 0.8,
          }}
        />
      </AbsoluteFill>
    );

  if (variant === "light")
    return (
      <AbsoluteFill style={{ background: theme.light.bg }}>
        <Blob x={380 + s1 * 70} y={260} s={1100} color={theme.light.blob} blur={60} />
        <Blob x={1560 - c1 * 60} y={860} s={1000} color={theme.light.blob} blur={60} />
        <AbsoluteFill
          style={{
            backgroundImage: `radial-gradient(${theme.alpha.ink(0.10)} 1.6px, transparent 1.8px)`,
            backgroundSize: "44px 44px",
            backgroundPosition: `${frame * 0.3}px ${frame * 0.2}px`,
            WebkitMaskImage: "radial-gradient(ellipse at 50% 50%, black 10%, transparent 75%)",
            maskImage: "radial-gradient(ellipse at 50% 50%, black 10%, transparent 75%)",
          }}
        />
      </AbsoluteFill>
    );

  if (variant === "mesh")
    return (
      <AbsoluteFill style={{ background: theme.colors.bg }}>
        <Blob x={330 + s1 * 70} y={200 + c1 * 40} s={1250} color={`${theme.alpha.white(0.10)}`} />
        <Blob x={1620 - c1 * 70} y={900 + s2 * 40} s={1150} color={`${theme.alpha.accent(0.24)}`} />
        <Blob x={1000 + s2 * 120} y={560} s={800} color={`${theme.alpha.white(0.045)}`} />
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            style={{
              position: "absolute",
              top: -200,
              left: ((frame * (1.2 + i * 0.5) + i * 700) % 2600) - 400,
              width: 90 + i * 40,
              height: 1600,
              transform: "rotate(24deg)",
              background: `linear-gradient(90deg, transparent, ${theme.alpha.white(0.045)}, transparent)`,
            }}
          />
        ))}
      </AbsoluteFill>
    );

  if (variant === "spot")
    return (
      <AbsoluteFill style={{ background: theme.colors.bg }}>
        <AbsoluteFill
          style={{
            background: `radial-gradient(ellipse at ${50 + s1 * 5}% -8%, ${theme.alpha.white(0.20)}, ${theme.alpha.white(0)} 62%)`,
          }}
        />
        <Blob x={960} y={1100} s={1500} color={`${theme.alpha.accent(0.22)}`} blur={90} />
        <AbsoluteFill
          style={{
            backgroundImage: `radial-gradient(${theme.alpha.text(0.10)} 1.4px, transparent 1.6px)`,
            backgroundSize: "52px 52px",
            WebkitMaskImage: "linear-gradient(180deg, black, transparent 80%)",
            maskImage: "linear-gradient(180deg, black, transparent 80%)",
            backgroundPosition: `0px ${frame * 0.4}px`,
          }}
        />
      </AbsoluteFill>
    );

  // globe
  const g = globe ?? { cx: 1380, cy: 540, R: 440, op: 1 };
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <Blob x={g.cx} y={g.cy} s={g.R * 3} color={`${theme.alpha.accent(0.16)}`} blur={90} />
      <Stars op={0.6} />
      <Globe cx={g.cx} cy={g.cy} R={g.R} op={g.op ?? 1} />
    </AbsoluteFill>
  );
};
