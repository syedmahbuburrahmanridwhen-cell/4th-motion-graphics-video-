import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { SpringName, theme } from "../theme";
import { useC } from "./Tone";

export const CL = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

/** spring অগ্রগতি (০→১+); delay-এর আগে ০ */
export const useSp = (delay = 0, preset: SpringName = "smooth") => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const f = frame - delay;
  if (f < 0) return 0;
  return spring({ frame: f, fps, config: theme.spring[preset] });
};

/** প্রস্থান অগ্রগতি (০→১), দ্রুত */
export const useOut = (out?: number, len: number = theme.motion.exit) => {
  const frame = useCurrentFrame();
  if (out === undefined) return 0;
  return interpolate(frame, [out, out + len], [0, 1], { ...CL, easing: theme.ease.in });
};

/** ইজড ০→১ র‍্যাম্প (ফ্রেম a থেকে b) */
export const ramp = (frame: number, a: number, b: number, easing = theme.ease.out) =>
  interpolate(frame, [a, b], [0, 1], { ...CL, easing });

const DIRS = {
  bottom: [0, 1],
  top: [0, -1],
  left: [-1, 0],
  right: [1, 0],
  none: [0, 0],
} as const;

type PopProps = {
  delay?: number;
  out?: number;
  from?: keyof typeof DIRS;
  dist?: number;
  s?: number;
  preset?: SpringName;
  blur?: number;
  origin?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
};

/** প্রিমিয়াম প্রবেশ: opacity + translate + scale (+ blur); প্রস্থানও আছে */
export const Pop: React.FC<PopProps> = ({
  delay = 0,
  out,
  from = "bottom",
  dist = 40,
  s = 0.94,
  preset = "smooth",
  blur = 0,
  origin = "50% 50%",
  style,
  children,
}) => {
  const p = useSp(delay, preset);
  const o = useOut(out);
  const k = 1 - p;
  const [dx, dy] = DIRS[from];
  const tx = dx * dist * k - dx * dist * 0.4 * o;
  const ty = dy * dist * k - dy * dist * 0.4 * o;
  const sc = (s + (1 - s) * p) * (1 - 0.05 * o);
  const op = Math.max(0, Math.min(1, p * 1.5)) * (1 - o);
  const bl = blur * k + o * 5;
  return (
    <div
      style={{
        opacity: op,
        transform: `translate(${tx}px, ${ty}px) scale(${sc})`,
        transformOrigin: origin,
        filter: bl > 0.2 ? `blur(${bl}px)` : undefined,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

type WordsProps = {
  text: string;
  size: number;
  delay?: number;
  per?: number;
  weight?: number;
  align?: "left" | "center" | "right";
  hero?: number[]; // সর্বোচ্চ কনট্রাস্ট শব্দ
  dim?: number[]; // ম্লান শব্দ
  grad?: number[]; // গ্রেডিয়েন্ট কীওয়ার্ড
  mark?: number[]; // হাইলাইট সুইপ
  out?: number;
  maxWidth?: number;
  lh?: number;
  style?: React.CSSProperties;
};

/**
 * শব্দ-বাই-শব্দ স্ট্যাগার্ড টেক্সট।
 * বাংলা নিয়ম: শুধু স্পেসে ভাঙে, অক্ষর ধরে কখনো নয়; letterSpacing: 0।
 */
export const Words: React.FC<WordsProps> = ({
  text,
  size,
  delay = 0,
  per = 4,
  weight = theme.weight.heavy,
  align = "left",
  hero = [],
  dim = [],
  grad = [],
  mark = [],
  out,
  maxWidth,
  lh = 1.32,
  style,
}) => {
  const frame = useCurrentFrame();
  const c = useC();
  const words = text.split(" ").filter(Boolean);
  const justify = align === "center" ? "center" : align === "right" ? "flex-end" : "flex-start";
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: justify,
        columnGap: Math.round(size * 0.26),
        rowGap: Math.round(size * 0.02),
        maxWidth,
        fontFamily: theme.fonts.main,
        fontSize: size,
        fontWeight: weight,
        lineHeight: lh,
        letterSpacing: 0,
        color: c.fg,
        ...style,
      }}
    >
      {words.map((w, i) => {
        const d = delay + i * per;
        const p = useSp(d, "snappy");
        const wo = out === undefined ? 0 : interpolate(frame, [out + i, out + i + theme.motion.exit], [0, 1], { ...CL, easing: theme.ease.in });
        const isHero = hero.includes(i);
        const isDim = dim.includes(i);
        const isGrad = grad.includes(i);
        const isMark = mark.includes(i);
        const barP = isMark ? ramp(frame, d + 8, d + 26) : 0;
        let color = isHero ? c.hero : isDim ? c.dim : c.fg;
        if (isMark && barP > 0.55) color = c.onHero;
        const shine = interpolate(frame, [d, d + 120], [0, 100], { ...CL });
        const gradStyle: React.CSSProperties = isGrad
          ? {
              backgroundImage: `linear-gradient(100deg, ${c.hero} 0%, ${c.dim} 55%, ${c.hero} 100%)`,
              backgroundSize: "220% 100%",
              backgroundPosition: `${100 - shine}% 0%`,
              WebkitBackgroundClip: "text",
              backgroundClip: "text",
              WebkitTextFillColor: "transparent",
              color: "transparent",
            }
          : {};
        return (
          <span
            key={i}
            style={{
              position: "relative",
              display: "inline-block",
              opacity: Math.max(0, Math.min(1, p * 1.5)) * (1 - wo),
              transform: `translateY(${(1 - p) * size * 0.34 - wo * size * 0.18}px) scale(${0.9 + 0.1 * p})`,
              filter: (1 - p) * 8 + wo * 5 > 0.3 ? `blur(${(1 - p) * 8 + wo * 5}px)` : undefined,
              color,
              padding: isMark ? `0 ${Math.round(size * 0.16)}px` : undefined,
              ...gradStyle,
            }}
          >
            {isMark && (
              <span
                style={{
                  position: "absolute",
                  left: 0,
                  right: 0,
                  top: "10%",
                  bottom: "6%",
                  borderRadius: Math.round(size * 0.22),
                  background: c.hero,
                  transformOrigin: "0% 50%",
                  transform: `scaleX(${barP})`,
                  zIndex: -1,
                }}
              />
            )}
            {w}
          </span>
        );
      })}
    </div>
  );
};

/** অলস অবস্থায় শ্বাস-প্রশ্বাসের মাইক্রো-মোশন */
export const useBreathe = (period = 90, amp = 0.012, phase = 0) => {
  const frame = useCurrentFrame();
  return 1 + Math.sin((frame / period) * Math.PI * 2 + phase) * amp;
};
export const useFloat = (amp = 6, period = 120, phase = 0) => {
  const frame = useCurrentFrame();
  return Math.sin((frame / period) * Math.PI * 2 + phase) * amp;
};
