import React, { createContext, useContext } from "react";
import { theme } from "../theme";

export type Tone = "dark" | "light";
const ToneCtx = createContext<Tone>("dark");
export const ToneProvider: React.FC<{ tone: Tone; children: React.ReactNode }> = ({ tone, children }) => (
  <ToneCtx.Provider value={tone}>{children}</ToneCtx.Provider>
);
export const useTone = () => useContext(ToneCtx);

/** টোন অনুযায়ী সিমান্টিক রং */
export const useC = () => {
  const tone = useTone();
  if (tone === "dark") {
    return {
      tone,
      fg: theme.colors.text,
      hero: theme.colors.hero,
      dim: theme.colors.accent,
      surface: theme.colors.panel,
      surfaceHi: theme.colors.panelHi,
      line: theme.colors.line,
      lineStrong: theme.colors.lineStrong,
      shadow: theme.colors.shadow,
      bg: theme.colors.bg,
      onHero: theme.colors.bg, // হিরো রঙের উপর লেখা
    };
  }
  return {
    tone,
    fg: theme.light.fg,
    hero: theme.light.ink,
    dim: theme.light.dim,
    surface: theme.light.panel,
    surfaceHi: theme.light.bgAlt,
    line: theme.light.line,
    lineStrong: theme.light.lineStrong,
    shadow: theme.light.shadow,
    bg: theme.light.bg,
    onHero: theme.light.bg,
  };
};
