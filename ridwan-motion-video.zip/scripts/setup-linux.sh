#!/usr/bin/env bash
# GitHub Codespaces/Ubuntu-তে Remotion-এর Chrome চালাতে দরকারি লাইব্রেরি (একবারই চালাতে হয়)
sudo apt-get update -y
sudo apt-get install -y libnss3 libdbus-1-3 libatk1.0-0 libgbm-dev libxrandr2 libxkbcommon-dev libxfixes3 libxcomposite1 libxdamage1 libatk-bridge2.0-0 libpango-1.0-0 libcairo2 libcups2
sudo apt-get install -y libasound2 || sudo apt-get install -y libasound2t64
