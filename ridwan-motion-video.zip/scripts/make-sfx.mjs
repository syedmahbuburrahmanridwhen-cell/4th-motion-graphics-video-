// make-sfx.mjs — SFX কোডে সিন্থেসাইজ (কোনো ডাউনলোড লাগে না, ফলাফল নির্দিষ্ট/ডিটারমিনিস্টিক)
// pop = নিচে-নামা pitch সহ sine; click = high-pass noise burst; whoosh = band-pass noise sweep;
// pluck/chime = নরম ওভারটোনসহ ছোট decay; thud = খুব নরম লো-সাইন।
// সব সাউন্ডে হালকা low-pass + খুব ছোট reverb। চালান: node scripts/make-sfx.mjs
import { writeFileSync, mkdirSync } from "node:fs";

const SR = 44100;
const OUT = new URL("../public/sfx/", import.meta.url).pathname;
mkdirSync(OUT, { recursive: true });

// ডিটারমিনিস্টিক র‍্যান্ডম
let seed = 1234567;
const rnd = () => {
  seed = (seed * 1664525 + 1013904223) >>> 0;
  return seed / 4294967296 * 2 - 1;
};

const N = (sec) => Math.floor(sec * SR);
const smoothAttack = (t, a) => (t >= a ? 1 : (1 - Math.cos(Math.PI * (t / a))) / 2);

const lowpass = (x, fc) => {
  const a = 1 - Math.exp((-2 * Math.PI * fc) / SR);
  let y = 0;
  return x.map((v) => (y += a * (v - y)));
};
const highpass = (x, fc) => {
  const lp = lowpass(x, fc);
  return x.map((v, i) => v - lp[i]);
};
const reverb = (x, mix = 0.16) => {
  const taps = [[0.023, 0.5], [0.031, 0.42], [0.047, 0.36]];
  const tail = N(0.09);
  const y = new Float32Array(x.length + tail);
  y.set(x);
  const wet = new Float32Array(y.length);
  for (const [d, g] of taps) {
    const k = N(d);
    for (let i = 0; i < x.length; i++) {
      wet[i + k] += x[i] * g;
      if (i + 2 * k < y.length) wet[i + 2 * k] += x[i] * g * 0.4;
    }
  }
  const wl = lowpass(Array.from(wet), 3500);
  for (let i = 0; i < y.length; i++) y[i] += wl[i] * mix;
  return y;
};
const fadeEnd = (x, sec = 0.03) => {
  const n = N(sec);
  for (let i = 0; i < n; i++) x[x.length - 1 - i] *= i / n;
  return x;
};

const gen = {
  pop() {
    const len = N(0.22);
    const x = new Float32Array(len);
    let ph = 0;
    for (let i = 0; i < len; i++) {
      const t = i / SR;
      const f = 190 + 520 * Math.exp(-t / 0.032);
      ph += (2 * Math.PI * f) / SR;
      const env = smoothAttack(t, 0.003) * Math.exp(-t / 0.055);
      x[i] = (Math.sin(ph) + 0.16 * Math.sin(2 * ph)) * env;
    }
    return x;
  },
  click() {
    const len = N(0.07);
    const noise = Array.from({ length: len }, () => rnd());
    const hp = highpass(noise, 2600);
    const x = new Float32Array(len);
    let ph = 0;
    for (let i = 0; i < len; i++) {
      const t = i / SR;
      ph += (2 * Math.PI * 1900) / SR;
      x[i] = hp[i] * smoothAttack(t, 0.0006) * Math.exp(-t / 0.0065) + 0.45 * Math.sin(ph) * Math.exp(-t / 0.009);
    }
    return x;
  },
  whoosh() {
    const dur = 0.7;
    const len = N(dur);
    const x = new Float32Array(len);
    let low = 0, band = 0;
    const Q = 1.15;
    for (let i = 0; i < len; i++) {
      const t = i / SR;
      const fc = 350 * Math.pow(3400 / 350, Math.pow(t / dur, 0.9));
      const f = 2 * Math.sin((Math.PI * fc) / SR);
      const inp = rnd();
      low += f * band;
      const high = inp - low - band / Q;
      band += f * high;
      const env = Math.pow(Math.sin((Math.PI * t) / dur), 1.6);
      x[i] = band * env;
    }
    return x;
  },
  pluck() {
    const len = N(0.42);
    const x = new Float32Array(len);
    const parts = [[587, 1, 0.19], [1181, 0.34, 0.12], [1775, 0.15, 0.08], [2407, 0.06, 0.05]];
    for (let i = 0; i < len; i++) {
      const t = i / SR;
      let s = 0;
      for (const [f, a, d] of parts) s += a * Math.sin(2 * Math.PI * f * t) * Math.exp(-t / d);
      x[i] = s * smoothAttack(t, 0.004);
    }
    return x;
  },
  chime() {
    const len = N(0.42);
    const x = new Float32Array(len);
    const parts = [[880, 1, 0.22], [1320, 0.5, 0.16], [1762, 0.3, 0.11], [2640, 0.1, 0.07]];
    for (let i = 0; i < len; i++) {
      const t = i / SR;
      let s = 0;
      for (const [f, a, d] of parts) s += a * Math.sin(2 * Math.PI * f * t) * Math.exp(-t / d);
      x[i] = s * smoothAttack(t, 0.008);
    }
    return x;
  },
  thud() {
    const len = N(0.32);
    const x = new Float32Array(len);
    let ph = 0;
    for (let i = 0; i < len; i++) {
      const t = i / SR;
      const f = 48 + 52 * Math.exp(-t / 0.06);
      ph += (2 * Math.PI * f) / SR;
      x[i] = Math.sin(ph) * smoothAttack(t, 0.006) * Math.exp(-t / 0.09);
    }
    return x;
  },
};

// প্রতি সাউন্ডের লো-পাস কাট-অফ
const LP = { pop: 4800, click: 9000, whoosh: 5200, pluck: 5500, chime: 6000, thud: 260 };
const TARGET_RMS = 0.13;
const PEAK_MAX = 0.88;

const wav16 = (x) => {
  const buf = Buffer.alloc(44 + x.length * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + x.length * 2, 4); buf.write("WAVE", 8);
  buf.write("fmt ", 12); buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34);
  buf.write("data", 36); buf.writeUInt32LE(x.length * 2, 40);
  for (let i = 0; i < x.length; i++) buf.writeInt16LE(Math.round(Math.max(-1, Math.min(1, x[i])) * 32767), 44 + i * 2);
  return buf;
};

console.log("name     dur(s)  peak   rms    clip");
for (const name of Object.keys(gen)) {
  let x = Array.from(gen[name]());
  x = lowpass(x, LP[name]);
  x = Array.from(reverb(Float32Array.from(x), name === "thud" ? 0.06 : 0.16));
  x = Array.from(fadeEnd(Float32Array.from(x)));
  // সক্রিয় অংশের RMS মিলিয়ে নেওয়া (লাউডনেস সমতা)
  const act = x.filter((v) => Math.abs(v) > 0.01);
  const rms0 = Math.sqrt(act.reduce((s, v) => s + v * v, 0) / Math.max(1, act.length));
  let g = TARGET_RMS / rms0;
  let peak = Math.max(...x.map(Math.abs)) * g;
  if (peak > PEAK_MAX) g *= PEAK_MAX / peak; // clipping এড়াতে
  x = x.map((v) => v * g);
  peak = Math.max(...x.map(Math.abs));
  const rms = Math.sqrt(x.filter((v) => Math.abs(v) > 0.01).reduce((s, v) => s + v * v, 0) / Math.max(1, act.length));
  writeFileSync(`${OUT}${name}.wav`, wav16(Float32Array.from(x)));
  console.log(`${name.padEnd(8)} ${(x.length / SR).toFixed(2).padStart(5)}  ${peak.toFixed(2)}  ${rms.toFixed(3)}  ${peak >= 0.999 ? "CLIP" : "no"}`);
}
