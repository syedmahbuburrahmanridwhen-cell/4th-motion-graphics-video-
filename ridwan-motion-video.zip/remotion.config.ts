import { Config } from "@remotion/cli/config";

// `npx remotion studio` ও `npx remotion render` দুটোই এই entry দিয়ে চলে
Config.setEntryPoint("./src/index.ts");
Config.setVideoImageFormat("jpeg");
Config.setCodec("h264");
Config.setCrf(18);
Config.setOverwriteOutput(true);
